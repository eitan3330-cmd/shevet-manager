// Configure your API URL in .env file: VITE_API_URL=https://your-server.com
  export const API_BASE = import.meta.env.VITE_API_URL || "";
  