import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth, ROLE_NAMES } from "@/hooks/use-auth";
import { useListPermissions } from "@/lib/api-hooks";
import {
  Users, CalendarCheck, CalendarRange, Wallet, ShoppingCart,
  ShieldCheck, LayoutDashboard, LogOut, Menu, Archive,
  ChevronDown, ChevronLeft, BookOpen, Home, FileText, UserCog, ClipboardList, CalendarDays
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface NavSection {
  id: string;
  label: string;
  icon: React.ElementType;
  href: string;
  show: boolean;
  children?: {
    href: string;
    label: string;
    icon: React.ElementType;
  }[];
}

export function Layout({ children }: { children: ReactNode }) {
  const { role, user, logout } = useAuth();
  const [location] = useLocation();

  const { data: permissions = [] } = useListPermissions({ query: { enabled: !!role } });
  const canHadracha = role === "marcaz_boger" || permissions.some(p => p.role === role && p.section === "hadracha" && p.canAccess);
  const canLogistics = role === "marcaz_boger" || permissions.some(p => p.role === role && p.section === "logistics" && p.canAccess);
  const isAdmin = role === "marcaz_boger";

  const sections: NavSection[] = [
    {
      id: "home",
      label: "ראשי",
      icon: Home,
      href: "/dashboard",
      show: true,
    },
    {
      id: "tasks",
      label: "משימות",
      icon: ClipboardList,
      href: "/tasks",
      show: true,
    },
    {
      id: "schedule",
      label: "לוז שבטי",
      icon: CalendarDays,
      href: "/schedule",
      show: true,
    },
    {
      id: "hadracha",
      label: "הדרכה",
      icon: BookOpen,
      href: "/hadracha",
      show: canHadracha,
      children: [
        { href: "/hadracha/scouts", label: "מאגר חניכים", icon: Users },
        { href: "/hadracha/attendance", label: "נוכחות", icon: CalendarCheck },
        { href: "/hadracha/activities", label: "הגשת פעולות", icon: FileText },
      ],
    },
    {
      id: "logistics",
      label: "לוגיסטיקה",
      icon: ShoppingCart,
      href: "/logistics",
      show: canLogistics,
      children: [
        { href: "/logistics/events", label: "מפעלים", icon: CalendarRange },
        { href: "/logistics/budget", label: "תקציב", icon: Wallet },
        { href: "/logistics/procurement", label: "הזמנות רכש", icon: ShoppingCart },
      ],
    },
    {
      id: "management",
      label: "ניהול",
      icon: UserCog,
      href: "/management",
      show: isAdmin,
      children: [
        { href: "/admin", label: "משתמשים והרשאות", icon: ShieldCheck },
        { href: "/years", label: "ארכיון שנים", icon: Archive },
      ],
    },
  ];

  const inSection = (section: NavSection) =>
    location === section.href || location.startsWith(`${section.href}/`);

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-sidebar border-l border-sidebar-border text-sidebar-foreground">
      <div className="p-5 border-b border-sidebar-border/20">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-6 rounded-full bg-white/80" />
          <h1 className="text-xl font-bold text-white tracking-tight">מנהל השבט</h1>
          <div className="w-2 h-6 rounded-full bg-red-400" />
        </div>
        <div className="mt-2 space-y-0.5">
          {user?.name && <p className="text-white font-semibold text-base leading-tight">{user.name}</p>}
          <span className="text-xs text-white/60 bg-white/10 py-0.5 px-2.5 rounded-full inline-block">
            {role ? ROLE_NAMES[role] : ""}
          </span>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {sections.filter(s => s.show).map((section) => {
          const isActive = location === section.href;
          const isExpanded = inSection(section);
          const SectionIcon = section.icon;

          return (
            <div key={section.id}>
              <Link href={section.href}>
                <span className={`flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg transition-all cursor-pointer group ${
                  isExpanded
                    ? "bg-red-500 text-white font-semibold shadow-sm"
                    : "text-white/80 hover:bg-white/10 hover:text-white"
                }`}>
                  <div className="flex items-center gap-2.5">
                    <SectionIcon className="w-5 h-5 shrink-0" />
                    <span className="text-sm font-medium">{section.label}</span>
                  </div>
                  {section.children && (
                    <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                  )}
                </span>
              </Link>

              {section.children && isExpanded && (
                <div className="mt-1 mr-4 space-y-0.5 border-r border-white/20 pr-2">
                  {section.children.map((child) => {
                    const childActive = location === child.href || location.startsWith(`${child.href}/`);
                    const ChildIcon = child.icon;
                    return (
                      <Link key={child.href} href={child.href}>
                        <span className={`flex items-center gap-2.5 px-3 py-2 rounded-md transition-all cursor-pointer text-sm ${
                          childActive
                            ? "bg-white/20 text-white font-medium"
                            : "text-white/70 hover:bg-white/10 hover:text-white"
                        }`}>
                          <ChildIcon className="w-4 h-4 shrink-0" />
                          {child.label}
                        </span>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="p-3 border-t border-sidebar-border/20">
        <Button
          variant="ghost"
          className="w-full justify-start text-white/70 hover:text-white hover:bg-white/10 text-sm"
          onClick={() => logout()}
        >
          <LogOut className="w-4 h-4 ml-2" />
          התנתק
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <aside className="hidden md:flex w-60 flex-col shrink-0 border-l border-border">
        <SidebarContent />
      </aside>

      <div className="flex flex-col flex-1 w-full overflow-hidden">
        <header className="md:hidden flex items-center justify-between p-4 bg-sidebar text-white border-b border-sidebar-border shadow-sm z-10">
          <div className="flex items-center gap-3">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="p-0 w-64 bg-sidebar border-none">
                <SidebarContent />
              </SheetContent>
            </Sheet>
            <h1 className="text-lg font-bold">מנהל השבט</h1>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="mx-auto max-w-6xl animate-in fade-in duration-300">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
