import { useState, useEffect } from "react";
import { useAuth, ROLE_NAMES, Role } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShieldCheck, ChevronLeft, Users, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const ROLE_COLORS: Record<string, { bg: string; text: string; border: string; dot: string }> = {
  marcaz_boger: { bg: "bg-blue-600", text: "text-white", border: "border-blue-700", dot: "bg-blue-200" },
  marcaz_tzair: { bg: "bg-red-600", text: "text-white", border: "border-red-700", dot: "bg-red-200" },
  roshatz: { bg: "bg-sky-500", text: "text-white", border: "border-sky-600", dot: "bg-sky-200" },
  roshgad: { bg: "bg-rose-500", text: "text-white", border: "border-rose-600", dot: "bg-rose-200" },
};

const DEFAULT_ROLES: { role: Role; name: string }[] = [
  { role: "marcaz_boger", name: "מרכז בוגר" },
  { role: "marcaz_tzair", name: "מרכז צעיר" },
  { role: "roshatz", name: "ראשצ" },
  { role: "roshgad", name: "ראשגד" },
];

const API_BASE = import.meta.env.VITE_API_URL || "";

export function Login() {
  const { user, setUser, setRole } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user?.id) setLocation("/dashboard");
  }, [user]);

  const { data: dbUsers = [], isLoading } = useQuery({
    queryKey: ["tribe-users"],
    queryFn: async () => {
      const res = await fetch(`${API_BASE}/api/users`);
      return res.json();
    },
  });

  const hasDbUsers = dbUsers.length > 0;

  const handleUserLogin = (dbUser: any) => {
    setUser({ id: dbUser.id, name: dbUser.name, role: dbUser.role as Role });
    setLocation("/dashboard");
  };

  const handleRoleLogin = (role: Role) => {
    setRole(role);
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-50 via-blue-50/30 to-red-50/20">
      <div className="w-full max-w-lg space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-3 h-16 rounded-full bg-blue-600 shadow-lg" />
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-2xl">
              <ShieldCheck className="w-10 h-10 text-white" />
            </div>
            <div className="w-3 h-16 rounded-full bg-red-600 shadow-lg" />
          </div>
          <div>
            <h1 className="text-4xl font-bold tracking-tight">מנהל השבט</h1>
            <p className="text-muted-foreground text-base mt-2">
              {hasDbUsers ? "בחר את המשתמש שלך" : "בחר את התפקיד שלך"}
            </p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : hasDbUsers ? (
          <div className="space-y-3">
            {dbUsers.map((u: any) => {
              const colors = ROLE_COLORS[u.role] || ROLE_COLORS.roshgad;
              return (
                <button
                  key={u.id}
                  onClick={() => handleUserLogin(u)}
                  className={`
                    w-full flex items-center justify-between p-4 rounded-2xl border-2 
                    transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0
                    ${colors.bg} ${colors.border} group
                  `}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full ${colors.dot} flex items-center justify-center text-lg font-bold text-slate-700`}>
                      {u.name.charAt(0)}
                    </div>
                    <div className="text-right">
                      <p className={`text-xl font-bold ${colors.text}`}>{u.name}</p>
                      <p className={`text-sm ${colors.text} opacity-80`}>{ROLE_NAMES[u.role] || u.role}</p>
                    </div>
                  </div>
                  <ChevronLeft className={`w-6 h-6 ${colors.text} opacity-70 group-hover:opacity-100 transition-opacity`} />
                </button>
              );
            })}
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 rounded-lg px-3 py-2 mb-4">
              <Users className="w-4 h-4" />
              <span>אין משתמשים — מרכז בוגר יכול להוסיף אנשים לאחר הכניסה</span>
            </div>
            {DEFAULT_ROLES.map((r) => {
              const colors = ROLE_COLORS[r.role];
              return (
                <button
                  key={r.role}
                  onClick={() => handleRoleLogin(r.role)}
                  className={`
                    w-full flex items-center justify-between p-4 rounded-2xl border-2
                    transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0
                    ${colors.bg} ${colors.border} group
                  `}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full ${colors.dot} flex items-center justify-center`}>
                      <ShieldCheck className="w-5 h-5 text-slate-700" />
                    </div>
                    <p className={`text-xl font-bold ${colors.text}`}>{r.name}</p>
                  </div>
                  <ChevronLeft className={`w-6 h-6 ${colors.text} opacity-70 group-hover:opacity-100 transition-opacity`} />
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
