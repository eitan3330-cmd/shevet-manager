import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, CalendarDays, MapPin, User, ChevronRight, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const API_BASE = import.meta.env.VITE_API_URL || "";

const EVENT_TYPES = [
  { value: "event", label: "מפעל" },
  { value: "meeting", label: "ישיבה" },
  { value: "training", label: "הכשרה" },
  { value: "activity", label: "פעולה" },
  { value: "camp", label: "מחנה" },
  { value: "trip", label: "טיול" },
  { value: "holiday", label: "חג / חופש" },
  { value: "other", label: "אחר" },
];

const TYPE_COLORS: Record<string, string> = {
  event: "bg-blue-500", meeting: "bg-purple-500", training: "bg-amber-500",
  activity: "bg-green-500", camp: "bg-red-500", trip: "bg-teal-500",
  holiday: "bg-pink-500", other: "bg-slate-500",
};

const GRADE_LEVELS = [
  { value: "all", label: "כלל השבט" },
  { value: "chanichim_dv", label: "חניכים ד-ו" },
  { value: "chanichim_zh", label: "חניכים ז-ח" },
  { value: "chanichim_t", label: "כיתה ט" },
  { value: "paelim", label: "פעילים י-יב" },
  { value: "madrichim", label: "מדריכים" },
];

const HEBREW_MONTHS = ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"];

type Form = {
  title: string; description: string; date: string; endDate: string;
  type: string; responsiblePerson: string; location: string; gradeLevel: string; notes: string;
};
const EMPTY: Form = { title: "", description: "", date: "", endDate: "", type: "event", responsiblePerson: "", location: "", gradeLevel: "all", notes: "" };

export function Schedule() {
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<Form>(EMPTY);
  const [viewDate, setViewDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<"month" | "list">("month");
  const { toast } = useToast();
  const { role } = useAuth();
  const qc = useQueryClient();

  const canEdit = ["marcaz_boger", "marcaz_tzair"].includes(role || "");

  const { data: events = [], isLoading } = useQuery({
    queryKey: ["schedule"],
    queryFn: () => fetch(`${API_BASE}/api/schedule`).then(r => r.json()),
  });

  const createEvent = useMutation({
    mutationFn: (data: any) => fetch(`${API_BASE}/api/schedule`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["schedule"] }); setIsOpen(false); setForm(EMPTY); toast({ title: "אירוע נוסף ללוז" }); },
  });

  const updateEvent = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => fetch(`${API_BASE}/api/schedule/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["schedule"] }); setIsOpen(false); toast({ title: "אירוע עודכן" }); },
  });

  const deleteEvent = useMutation({
    mutationFn: (id: number) => fetch(`${API_BASE}/api/schedule/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["schedule"] }); toast({ title: "אירוע נמחק" }); },
  });

  const handleEdit = (e: any) => {
    setEditId(e.id);
    setForm({
      title: e.title, description: e.description || "", date: e.date?.split("T")[0] || "",
      endDate: e.endDate?.split("T")[0] || "", type: e.type, responsiblePerson: e.responsiblePerson || "",
      location: e.location || "", gradeLevel: e.gradeLevel || "all", notes: e.notes || "",
    });
    setIsOpen(true);
  };

  const handleSubmit = () => {
    const data = { ...form, date: form.date ? new Date(form.date).toISOString() : null, endDate: form.endDate ? new Date(form.endDate).toISOString() : null, gradeLevel: form.gradeLevel || null };
    if (editId) updateEvent.mutate({ id: editId, data });
    else createEvent.mutate(data);
  };

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();

  const monthEvents = (events as any[]).filter(e => {
    const d = new Date(e.date);
    return d.getFullYear() === year && d.getMonth() === month;
  });

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startDow = (firstDay.getDay() + 1) % 7;
  const days = Array.from({ length: lastDay.getDate() }, (_, i) => i + 1);

  const getEventsByDay = (day: number) => monthEvents.filter(e => new Date(e.date).getDate() === day);

  const upcomingEvents = (events as any[]).filter(e => new Date(e.date) >= new Date()).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).slice(0, 5);

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-3xl font-bold">לוז שבטי</h2>
          <p className="text-muted-foreground">לוח האירועים השנתי של השבט</p>
        </div>
        <div className="flex gap-2">
          <div className="flex rounded-lg border overflow-hidden text-sm">
            {[{ id: "month", label: "חודשי" }, { id: "list", label: "רשימה" }].map(m => (
              <button key={m.id} onClick={() => setViewMode(m.id as any)}
                className={`px-3 py-1.5 ${viewMode === m.id ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:bg-muted"}`}>
                {m.label}
              </button>
            ))}
          </div>
          {canEdit && (
            <Button onClick={() => { setEditId(null); setForm(EMPTY); setIsOpen(true); }} className="gap-2">
              <Plus className="w-4 h-4" /> הוסף ללוז
            </Button>
          )}
        </div>
      </div>

      {viewMode === "month" ? (
        <div className="space-y-3">
          {/* Month navigation */}
          <div className="flex items-center justify-between bg-card border rounded-xl p-3">
            <Button variant="ghost" size="icon" onClick={() => setViewDate(new Date(year, month + 1, 1))}><ChevronLeft className="w-4 h-4" /></Button>
            <h3 className="text-lg font-bold">{HEBREW_MONTHS[month]} {year}</h3>
            <Button variant="ghost" size="icon" onClick={() => setViewDate(new Date(year, month - 1, 1))}><ChevronRight className="w-4 h-4" /></Button>
          </div>

          {/* Calendar grid */}
          <div className="border rounded-xl overflow-hidden bg-card">
            <div className="grid grid-cols-7 bg-muted/30">
              {["א", "ב", "ג", "ד", "ה", "ו", "ש"].map(d => (
                <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 divide-x divide-y divide-border/50">
              {Array.from({ length: startDow }).map((_, i) => <div key={`empty-${i}`} className="min-h-[80px] bg-muted/10" />)}
              {days.map(day => {
                const dayEvents = getEventsByDay(day);
                const isToday = new Date().getDate() === day && new Date().getMonth() === month && new Date().getFullYear() === year;
                return (
                  <div key={day} className={`min-h-[80px] p-1.5 ${isToday ? "bg-primary/5" : ""}`}>
                    <span className={`text-sm font-medium inline-flex items-center justify-center w-6 h-6 rounded-full ${isToday ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{day}</span>
                    <div className="space-y-0.5 mt-1">
                      {dayEvents.slice(0, 3).map(e => (
                        <div key={e.id} className={`text-xs px-1.5 py-0.5 rounded text-white truncate ${TYPE_COLORS[e.type] || "bg-slate-500"}`} title={e.title}>
                          {e.title}
                        </div>
                      ))}
                      {dayEvents.length > 3 && <div className="text-xs text-muted-foreground pr-1">+{dayEvents.length - 3}</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Upcoming events */}
          {upcomingEvents.length > 0 && (
            <div className="border rounded-xl p-4 bg-card">
              <h4 className="font-semibold mb-3 text-sm text-muted-foreground">אירועים קרובים</h4>
              <div className="space-y-2">
                {upcomingEvents.map(e => (
                  <div key={e.id} className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${TYPE_COLORS[e.type] || "bg-slate-500"}`} />
                      <span className="font-medium text-sm truncate">{e.title}</span>
                      {e.gradeLevel && <Badge variant="outline" className="text-xs shrink-0">{GRADE_LEVELS.find(g => g.value === e.gradeLevel)?.label || e.gradeLevel}</Badge>}
                    </div>
                    <span className="text-xs text-muted-foreground shrink-0">{new Date(e.date).toLocaleDateString('he-IL')}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {isLoading ? (
            <div className="text-center py-12 text-muted-foreground">טוען...</div>
          ) : (events as any[]).length === 0 ? (
            <div className="text-center py-16 text-muted-foreground border rounded-xl">
              <CalendarDays className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>הלוז ריק — הוסף אירועים ראשונים</p>
            </div>
          ) : (
            (events as any[]).map(e => {
              const typeLabel = EVENT_TYPES.find(t => t.value === e.type)?.label || e.type;
              const gradeName = GRADE_LEVELS.find(g => g.value === e.gradeLevel)?.label;
              return (
                <div key={e.id} className="border rounded-xl p-4 bg-card flex items-start gap-3 hover:shadow-sm transition-shadow">
                  <div className={`w-3 shrink-0 h-full rounded-full mt-1 min-h-[40px] ${TYPE_COLORS[e.type] || "bg-slate-500"}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-semibold">{e.title}</h3>
                        {e.description && <p className="text-sm text-muted-foreground">{e.description}</p>}
                        <div className="flex gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                          <span className="flex items-center gap-0.5"><CalendarDays className="w-3 h-3" />{new Date(e.date).toLocaleDateString('he-IL')}{e.endDate && ` — ${new Date(e.endDate).toLocaleDateString('he-IL')}`}</span>
                          {e.location && <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" />{e.location}</span>}
                          {e.responsiblePerson && <span className="flex items-center gap-0.5"><User className="w-3 h-3" />{e.responsiblePerson}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Badge variant="outline" className="text-xs">{typeLabel}</Badge>
                        {gradeName && <Badge variant="outline" className="text-xs">{gradeName}</Badge>}
                        {canEdit && (
                          <>
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(e)}><Pencil className="w-3.5 h-3.5" /></Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => { if (confirm("למחוק?")) deleteEvent.mutate(e.id); }}><Trash2 className="w-3.5 h-3.5" /></Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "עריכת אירוע" : "הוספת אירוע ללוז"}</DialogTitle></DialogHeader>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto px-1">
            <Input placeholder="כותרת האירוע *" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">סוג</label>
                <Select value={form.type} onValueChange={v => setForm(p => ({ ...p, type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{EVENT_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">שכבה / קהל</label>
                <Select value={form.gradeLevel} onValueChange={v => setForm(p => ({ ...p, gradeLevel: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{GRADE_LEVELS.map(g => <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground">תאריך התחלה</label><Input type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} /></div>
              <div><label className="text-xs text-muted-foreground">תאריך סיום</label><Input type="date" value={form.endDate} onChange={e => setForm(p => ({ ...p, endDate: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground">מיקום</label><Input value={form.location} onChange={e => setForm(p => ({ ...p, location: e.target.value }))} /></div>
              <div><label className="text-xs text-muted-foreground">אחראי</label><Input value={form.responsiblePerson} onChange={e => setForm(p => ({ ...p, responsiblePerson: e.target.value }))} /></div>
            </div>
            <div><label className="text-sm font-medium">תיאור</label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={2} /></div>
            <div><label className="text-sm font-medium">הערות</label><Textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={2} /></div>
            <Button className="w-full" onClick={handleSubmit} disabled={!form.title || !form.date}>
              {editId ? "שמור שינויים" : "הוסף ללוז"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
