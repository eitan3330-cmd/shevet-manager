import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, TrendingDown, TrendingUp, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";

const API_BASE = import.meta.env.VITE_API_URL || "";

const CATEGORIES = [
  "הסעות", "ציוד", "מזון", "לינה", "פינוי", "מדריכים",
  "דלק", "כיבוד", "הדרכה", "פרסום", "כלים", "ביטוח", "אחר"
];

const CURRENT_YEAR = new Date().getFullYear() + "-" + (new Date().getFullYear() + 1);

type BudgetLine = {
  id: number; yearLabel: string; category: string; description?: string;
  allocatedAmount: number; spentAmount: number; lastYearAmount?: number; notes?: string;
};

type LineForm = {
  yearLabel: string; category: string; description: string;
  allocatedAmount: string; spentAmount: string; lastYearAmount: string; notes: string;
};

const EMPTY_FORM: LineForm = {
  yearLabel: CURRENT_YEAR, category: CATEGORIES[0], description: "",
  allocatedAmount: "", spentAmount: "0", lastYearAmount: "", notes: "",
};

export function BudgetLines() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<LineForm>(EMPTY_FORM);
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: lines = [], isLoading } = useQuery<BudgetLine[]>({
    queryKey: ["budget-lines"],
    queryFn: () => fetch(`${API_BASE}/api/budget-lines`).then(r => r.json()),
  });

  const createLine = useMutation({
    mutationFn: (data: any) => fetch(`${API_BASE}/api/budget-lines`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["budget-lines"] }); setIsOpen(false); setForm(EMPTY_FORM); toast({ title: "סעיף נוסף" }); },
  });

  const updateLine = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => fetch(`${API_BASE}/api/budget-lines/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["budget-lines"] }); setIsOpen(false); toast({ title: "סעיף עודכן" }); },
  });

  const deleteLine = useMutation({
    mutationFn: (id: number) => fetch(`${API_BASE}/api/budget-lines/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["budget-lines"] }); toast({ title: "סעיף נמחק" }); },
  });

  const handleEdit = (line: BudgetLine) => {
    setEditingId(line.id);
    setForm({
      yearLabel: line.yearLabel, category: line.category, description: line.description || "",
      allocatedAmount: String(line.allocatedAmount), spentAmount: String(line.spentAmount),
      lastYearAmount: line.lastYearAmount != null ? String(line.lastYearAmount) : "",
      notes: line.notes || "",
    });
    setIsOpen(true);
  };

  const handleSubmit = () => {
    const data = {
      yearLabel: form.yearLabel, category: form.category, description: form.description || null,
      allocatedAmount: parseFloat(form.allocatedAmount) || 0,
      spentAmount: parseFloat(form.spentAmount) || 0,
      lastYearAmount: form.lastYearAmount ? parseFloat(form.lastYearAmount) : null,
      notes: form.notes || null,
    };
    if (editingId) updateLine.mutate({ id: editingId, data });
    else createLine.mutate(data);
  };

  const totalAllocated = lines.reduce((s, l) => s + l.allocatedAmount, 0);
  const totalSpent = lines.reduce((s, l) => s + l.spentAmount, 0);
  const totalLastYear = lines.filter(l => l.lastYearAmount != null).reduce((s, l) => s + (l.lastYearAmount || 0), 0);
  const usagePercent = totalAllocated > 0 ? (totalSpent / totalAllocated) * 100 : 0;

  const barColor = usagePercent > 90 ? "bg-red-500" : usagePercent > 70 ? "bg-amber-500" : "bg-green-500";

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-3xl font-bold">תקציב שנתי</h2>
          <p className="text-muted-foreground">סעיפים תקציביים לפי קטגוריה</p>
        </div>
        <Button onClick={() => { setEditingId(null); setForm(EMPTY_FORM); setIsOpen(true); }} className="gap-2">
          <Plus className="w-4 h-4" /> הוסף סעיף
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card><CardContent className="pt-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-100"><Target className="w-5 h-5 text-blue-600" /></div>
            <div><p className="text-xs text-muted-foreground">תקציב מוקצה</p><p className="text-xl font-bold">₪{totalAllocated.toLocaleString()}</p></div>
          </div>
        </CardContent></Card>
        <Card><CardContent className="pt-5">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${usagePercent > 90 ? "bg-red-100" : "bg-amber-100"}`}>
              <TrendingDown className={`w-5 h-5 ${usagePercent > 90 ? "text-red-600" : "text-amber-600"}`} />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">הוצאה בפועל</p>
              <p className={`text-xl font-bold ${usagePercent > 90 ? "text-red-600" : ""}`}>₪{totalSpent.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">{usagePercent.toFixed(0)}% מהתקציב</p>
            </div>
          </div>
        </CardContent></Card>
        <Card><CardContent className="pt-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-slate-100"><TrendingUp className="w-5 h-5 text-slate-600" /></div>
            <div><p className="text-xs text-muted-foreground">שנה שעברה</p><p className="text-xl font-bold">₪{totalLastYear.toLocaleString()}</p></div>
          </div>
        </CardContent></Card>
      </div>

      <div className="space-y-1">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">ניצול תקציב</span>
          <span className="font-medium">{usagePercent.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-3">
          <div className={`h-3 rounded-full transition-all ${barColor}`} style={{ width: `${Math.min(usagePercent, 100)}%` }} />
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">טוען...</div>
      ) : lines.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground border rounded-xl">
          <Target className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>אין סעיפים תקציביים — הוסף סעיף ראשון</p>
        </div>
      ) : (
        <div className="border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/30">
                <th className="text-right p-3 font-medium">קטגוריה</th>
                <th className="text-right p-3 font-medium">תיאור</th>
                <th className="text-left p-3 font-medium">מוקצה</th>
                <th className="text-left p-3 font-medium">הוצאה</th>
                <th className="text-left p-3 font-medium">שנה שעברה</th>
                <th className="p-3 font-medium w-32">ניצול</th>
                <th className="p-3 w-20"></th>
              </tr>
            </thead>
            <tbody>
              {lines.map((line, i) => {
                const pct = line.allocatedAmount > 0 ? (line.spentAmount / line.allocatedAmount) * 100 : 0;
                const lineBar = pct > 90 ? "bg-red-500" : pct > 70 ? "bg-amber-500" : "bg-green-500";
                const diff = line.lastYearAmount != null ? line.allocatedAmount - line.lastYearAmount : null;
                return (
                  <tr key={line.id} className={i % 2 === 0 ? "bg-background" : "bg-muted/10"}>
                    <td className="p-3 font-medium">{line.category}</td>
                    <td className="p-3 text-muted-foreground text-xs">{line.description || "—"}</td>
                    <td className="p-3 text-left font-medium">₪{line.allocatedAmount.toLocaleString()}</td>
                    <td className={`p-3 text-left font-medium ${pct > 90 ? "text-red-600" : ""}`}>₪{line.spentAmount.toLocaleString()}</td>
                    <td className="p-3 text-left text-muted-foreground">
                      {line.lastYearAmount != null ? (
                        <div>
                          <span>₪{line.lastYearAmount.toLocaleString()}</span>
                          {diff !== null && (
                            <span className={`mr-1 text-xs ${diff > 0 ? "text-green-600" : "text-red-600"}`}>
                              {diff > 0 ? "+" : ""}{diff.toLocaleString()}
                            </span>
                          )}
                        </div>
                      ) : "—"}
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-muted rounded-full h-2">
                          <div className={`h-2 rounded-full ${lineBar}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                        </div>
                        <span className={`text-xs w-8 text-left ${pct > 90 ? "text-red-600 font-semibold" : "text-muted-foreground"}`}>{pct.toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(line)}><Pencil className="w-3.5 h-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => { if (confirm("למחוק?")) deleteLine.mutate(line.id); }}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-muted/50 font-semibold border-t">
                <td className="p-3" colSpan={2}>סיכום</td>
                <td className="p-3 text-left">₪{totalAllocated.toLocaleString()}</td>
                <td className={`p-3 text-left ${usagePercent > 90 ? "text-red-600" : ""}`}>₪{totalSpent.toLocaleString()}</td>
                <td className="p-3 text-left text-muted-foreground">₪{totalLastYear.toLocaleString()}</td>
                <td className="p-3" colSpan={2}>
                  <span className={usagePercent > 90 ? "text-red-600" : ""}>{usagePercent.toFixed(1)}%</span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>{editingId ? "עריכת סעיף" : "סעיף תקציבי חדש"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium">שנה</label>
                <Input value={form.yearLabel} onChange={e => setForm(p => ({ ...p, yearLabel: e.target.value }))} />
              </div>
              <div>
                <label className="text-sm font-medium">קטגוריה</label>
                <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">תיאור</label>
              <Input placeholder="תיאור הסעיף..." value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><label className="text-sm font-medium">תקציב מוקצה</label><Input type="number" placeholder="0" value={form.allocatedAmount} onChange={e => setForm(p => ({ ...p, allocatedAmount: e.target.value }))} /></div>
              <div><label className="text-sm font-medium">הוצאה בפועל</label><Input type="number" placeholder="0" value={form.spentAmount} onChange={e => setForm(p => ({ ...p, spentAmount: e.target.value }))} /></div>
              <div><label className="text-sm font-medium">שנה שעברה</label><Input type="number" placeholder="0" value={form.lastYearAmount} onChange={e => setForm(p => ({ ...p, lastYearAmount: e.target.value }))} /></div>
            </div>
            <div><label className="text-sm font-medium">הערות</label><Input value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} /></div>
            <Button className="w-full" onClick={handleSubmit} disabled={!form.category || createLine.isPending || updateLine.isPending}>
              {editingId ? "שמור שינויים" : "הוסף סעיף"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
