import { useState } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { useAuth, ROLE_NAMES } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { ShieldAlert, Plus, Trash2, Users, Shield, Search, ChevronDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const API_BASE = import.meta.env.VITE_API_URL || "";

const ROLE_OPTIONS = [
  { value: "marcaz_boger", label: "מרכז בוגר" },
  { value: "marcaz_tzair", label: "מרכז צעיר" },
  { value: "roshatz", label: "ראשצ" },
  { value: "roshgad", label: "ראשגד" },
];

const ROLE_COLORS: Record<string, string> = {
  marcaz_boger: "bg-blue-100 text-blue-800 border-blue-200",
  marcaz_tzair: "bg-red-100 text-red-800 border-red-200",
  roshatz: "bg-sky-100 text-sky-800 border-sky-200",
  roshgad: "bg-rose-100 text-rose-800 border-rose-200",
};

const SECTIONS = [
  {
    id: "hadracha", label: "מדור הדרכה", desc: "ניהול חניכים, נוכחות, פעולות",
    features: [
      { id: "scouts", label: "מאגר חניכים" },
      { id: "attendance", label: "נוכחות" },
      { id: "activities", label: "הגשת פעולות" },
    ],
  },
  {
    id: "logistics", label: "מדור לוגיסטיקה", desc: "מפעלים, תקציב, הזמנות רכש",
    features: [
      { id: "events", label: "מפעלים" },
      { id: "budget", label: "תקציב" },
      { id: "procurement", label: "הזמנות רכש" },
    ],
  },
];

const ROLE_KEYS = ["marcaz_tzair", "roshatz", "roshgad"];

export function Admin() {
  const { role } = useAuth();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [newUserName, setNewUserName] = useState("");
  const [newUserRole, setNewUserRole] = useState("marcaz_tzair");
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [addFromScout, setAddFromScout] = useState(false);
  const [scoutSearch, setScoutSearch] = useState("");
  const [expandedRole, setExpandedRole] = useState<string | null>(null);

  const { data: permissions = [], isLoading: permLoading } = useQuery({
    queryKey: ["permissions"],
    queryFn: () => fetch(`${API_BASE}/api/permissions`).then(r => r.json()),
  });

  const updatePerm = useMutation({
    mutationFn: (data: { role: string; section: string; feature?: string | null; canAccess: boolean }) =>
      fetch(`${API_BASE}/api/permissions`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["permissions"] }); toast({ title: "הרשאה עודכנה" }); },
  });

  const { data: scouts = [] } = useQuery({
    queryKey: ["scouts-raw"],
    queryFn: () => fetch(`${API_BASE}/api/scouts`).then(r => r.json()),
  });

  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["tribe-users"],
    queryFn: () => fetch(`${API_BASE}/api/users`).then(r => r.json()),
    enabled: role === "marcaz_boger",
  });

  const addUser = useMutation({
    mutationFn: () => fetch(`${API_BASE}/api/users`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: newUserName.trim(), role: newUserRole }) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["tribe-users"] }); toast({ title: `משתמש "${newUserName}" נוסף` }); setNewUserName(""); setIsAddingUser(false); },
    onError: () => toast({ title: "שגיאה ביצירת משתמש", variant: "destructive" }),
  });

  const removeUser = useMutation({
    mutationFn: (id: number) => fetch(`${API_BASE}/api/users/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["tribe-users"] }); toast({ title: "משתמש הוסר" }); },
  });

  if (role !== "marcaz_boger") {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
        <ShieldAlert className="w-16 h-16 text-destructive opacity-80" />
        <h2 className="text-2xl font-bold">אין גישה</h2>
        <p className="text-muted-foreground">עמוד זה מיועד למרכז בוגר בלבד.</p>
      </div>
    );
  }

  const getPerm = (r: string, section: string, feature?: string | null) =>
    (permissions as any[]).find(p => p.role === r && p.section === section && (feature ? p.feature === feature : p.feature === null))?.canAccess ?? true;

  const handleToggle = (r: string, section: string, feature: string | null, current: boolean) =>
    updatePerm.mutate({ role: r, section, feature, canAccess: !current });

  const filteredScouts = (scouts as any[]).filter(s => !scoutSearch || `${s.name} ${s.lastName || ""}`.includes(scoutSearch));

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">ניהול מערכת</h2>
        <p className="text-muted-foreground">ניהול משתמשים והרשאות גישה</p>
      </div>

      {/* Users card */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl"><Users className="w-5 h-5 text-primary" />משתמשי השבט</CardTitle>
          <CardDescription>הוסף את אנשי הצוות הפעילים השנה. כל אחד יוכל להיכנס על ידי בחירת שמו.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {usersLoading ? (
            <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-12 rounded-lg" />)}</div>
          ) : (
            <div className="space-y-2">
              {users.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground bg-muted/30 rounded-lg">
                  <Users className="w-8 h-8 mx-auto mb-2 opacity-40" /><p className="text-sm">אין משתמשים.</p>
                </div>
              ) : users.map((u: any) => (
                <div key={u.id} className="flex items-center justify-between p-3 rounded-lg border bg-card">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">{u.name.charAt(0)}</div>
                    <div>
                      <p className="font-semibold">{u.name}</p>
                      <Badge variant="outline" className={`text-xs ${ROLE_COLORS[u.role] || ""}`}>{ROLE_NAMES[u.role] || u.role}</Badge>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10 h-8 w-8" onClick={() => removeUser.mutate(u.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              ))}
            </div>
          )}

          {isAddingUser ? (
            <div className="p-4 rounded-lg border bg-muted/30 space-y-3">
              {newUserRole !== "marcaz_boger" && (
                <div className="flex gap-2 text-sm">
                  <button onClick={() => { setAddFromScout(false); setNewUserName(""); }}
                    className={`flex-1 py-1.5 rounded-lg border transition-all ${!addFromScout ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>
                    הזן ידנית
                  </button>
                  <button onClick={() => { setAddFromScout(true); setNewUserName(""); setScoutSearch(""); }}
                    className={`flex-1 py-1.5 rounded-lg border transition-all ${addFromScout ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>
                    בחר מרשימת חניכים
                  </button>
                </div>
              )}

              {addFromScout && newUserRole !== "marcaz_boger" ? (
                <div className="space-y-2">
                  <div className="relative">
                    <Search className="absolute right-3 top-2.5 w-4 h-4 text-muted-foreground" />
                    <Input className="pr-9" placeholder="חיפוש לפי שם..." value={scoutSearch} onChange={e => setScoutSearch(e.target.value)} />
                  </div>
                  <div className="max-h-48 overflow-y-auto border rounded-lg bg-background">
                    {filteredScouts.map((s: any) => (
                      <button key={s.id}
                        className={`w-full text-right px-3 py-2 text-sm hover:bg-muted/50 border-b border-border/30 last:border-0 flex items-center justify-between ${newUserName === s.name ? "bg-primary/10" : ""}`}
                        onClick={() => setNewUserName(s.name)}>
                        <span className="text-muted-foreground text-xs">{s.grade ? `כיתה ${s.grade}` : ""}{s.gizra ? ` • ${s.gizra}` : ""}</span>
                        <span className="font-medium">{s.name}{s.lastName ? ` ${s.lastName}` : ""}</span>
                      </button>
                    ))}
                    {filteredScouts.length === 0 && <p className="text-center text-muted-foreground py-3 text-sm">לא נמצאו חניכים</p>}
                  </div>
                  {newUserName && <p className="text-sm font-medium text-primary">נבחר: {newUserName}</p>}
                </div>
              ) : (
                <Input placeholder="שם המשתמש" value={newUserName} onChange={e => setNewUserName(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && newUserName.trim() && addUser.mutate()} />
              )}

              <div className="flex gap-2">
                <Select value={newUserRole} onValueChange={v => { setNewUserRole(v); if (v === "marcaz_boger") setAddFromScout(false); }}>
                  <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{ROLE_OPTIONS.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
                </Select>
                <Button onClick={() => addUser.mutate()} disabled={!newUserName.trim() || addUser.isPending}>הוסף</Button>
                <Button variant="ghost" onClick={() => { setIsAddingUser(false); setNewUserName(""); setAddFromScout(false); }}>ביטול</Button>
              </div>
            </div>
          ) : (
            <Button variant="outline" className="w-full gap-2" onClick={() => setIsAddingUser(true)}><Plus className="w-4 h-4" />הוסף משתמש</Button>
          )}
        </CardContent>
      </Card>

      {/* Permissions card */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl"><Shield className="w-5 h-5 text-primary" />הרשאות גישה</CardTitle>
          <CardDescription>שלוט מה כל תפקיד רואה — ברמת מדור ובתוך כל מדור בנפרד. למרכז בוגר יש גישה מלאה תמיד.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {permLoading ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-lg" />)
          ) : ROLE_KEYS.map(rk => (
            <div key={rk} className="border rounded-xl overflow-hidden">
              <button
                className="w-full flex items-center justify-between p-4 bg-muted/20 hover:bg-muted/40 transition-colors text-right"
                onClick={() => setExpandedRole(expandedRole === rk ? null : rk)}
              >
                <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${expandedRole === rk ? "rotate-180" : ""}`} />
                <p className="font-semibold">{ROLE_NAMES[rk] || rk}</p>
              </button>

              {expandedRole === rk && (
                <div className="p-4 space-y-4 border-t">
                  {SECTIONS.map(sec => {
                    const sectionOn = getPerm(rk, sec.id, null);
                    return (
                      <div key={sec.id} className="space-y-2">
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border">
                          <div>
                            <p className="font-medium text-sm">{sec.label}</p>
                            <p className="text-xs text-muted-foreground">{sec.desc}</p>
                          </div>
                          <Switch checked={sectionOn} onCheckedChange={() => handleToggle(rk, sec.id, null, sectionOn)} disabled={updatePerm.isPending} />
                        </div>
                        {sectionOn && (
                          <div className="mr-3 space-y-1.5 border-r border-muted pr-3">
                            {sec.features.map(feat => {
                              const featOn = getPerm(rk, sec.id, feat.id);
                              return (
                                <div key={feat.id} className="flex items-center justify-between px-3 py-2 rounded-md bg-background border hover:bg-muted/10 transition-colors">
                                  <span className="text-sm">{feat.label}</span>
                                  <Switch checked={featOn} onCheckedChange={() => handleToggle(rk, sec.id, feat.id, featOn)} disabled={updatePerm.isPending} />
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
