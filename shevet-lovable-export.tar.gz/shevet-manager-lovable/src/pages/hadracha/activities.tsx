import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, CheckCircle2, Clock, XCircle, FileText, Send, Download, Paperclip, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const API_BASE = import.meta.env.VITE_API_URL || "";

const ACTIVITY_TYPES = [
  { value: "peula", label: "פעולה" },
  { value: "tiyul", label: "טיול" },
  { value: "erev", label: "ערב" },
  { value: "shabaton", label: "שבתון" },
  { value: "special", label: "אירוע מיוחד" },
];

const GRADE_LEVELS = [
  { value: "chanichim", label: "חניכים (ד-ו)" },
  { value: "chanichim_bechirim", label: "חניכים בכירים (ז-ט)" },
  { value: "paelim", label: "פעילים (י-יב)" },
  { value: "madrichim", label: "מדריכים" },
  { value: "all", label: "כלל השבט" },
];

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  draft: { label: "טיוטה", color: "bg-slate-100 text-slate-700 border-slate-200", icon: Clock },
  submitted: { label: "הוגש", color: "bg-blue-100 text-blue-700 border-blue-200", icon: Send },
  approved: { label: "אושר", color: "bg-green-100 text-green-700 border-green-200", icon: CheckCircle2 },
  feedback: { label: "הערות", color: "bg-amber-100 text-amber-700 border-amber-200", icon: Pencil },
  rejected: { label: "נדחה", color: "bg-red-100 text-red-700 border-red-200", icon: XCircle },
};

type ActivityForm = {
  title: string; date: string; gradeLevel: string; activityType: string;
  description: string; goals: string; materials: string; duration: string;
  fileUrl: string; fileName: string;
};
const EMPTY_FORM: ActivityForm = {
  title: "", date: "", gradeLevel: "chanichim", activityType: "peula",
  description: "", goals: "", materials: "", duration: "", fileUrl: "", fileName: "",
};

export function Activities() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [viewId, setViewId] = useState<number | null>(null);
  const [feedbackId, setFeedbackId] = useState<number | null>(null);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackStatus, setFeedbackStatus] = useState("feedback");
  const [statusFilter, setStatusFilter] = useState("all");
  const [form, setForm] = useState<ActivityForm>(EMPTY_FORM);
  const [fileLoading, setFileLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { user, role } = useAuth();
  const qc = useQueryClient();

  const isPrivileged = ["marcaz_boger", "marcaz_tzair", "roshgad"].includes(role || "");

  const { data: activities = [], isLoading } = useQuery({
    queryKey: ["activities"],
    queryFn: () => fetch(`${API_BASE}/api/activities`).then(r => r.json()),
  });

  const createActivity = useMutation({
    mutationFn: (data: any) => fetch(`${API_BASE}/api/activities`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["activities"] }); setIsOpen(false); setForm(EMPTY_FORM); toast({ title: "פעולה נשמרה" }); },
  });

  const updateActivity = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => fetch(`${API_BASE}/api/activities/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["activities"] }); setIsOpen(false); setFeedbackId(null); setFeedbackText(""); toast({ title: "עודכן" }); },
  });

  const deleteActivity = useMutation({
    mutationFn: (id: number) => fetch(`${API_BASE}/api/activities/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["activities"] }); toast({ title: "נמחק" }); },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast({ title: "קובץ גדול מדי (מקסימום 5MB)", variant: "destructive" }); return; }
    setFileLoading(true);
    const reader = new FileReader();
    reader.onload = ev => {
      const base64 = ev.target?.result as string;
      setForm(p => ({ ...p, fileUrl: base64, fileName: file.name }));
      setFileLoading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleEdit = (a: any) => {
    setEditingId(a.id);
    setForm({ title: a.title, date: a.date ? a.date.split("T")[0] : "", gradeLevel: a.gradeLevel || "chanichim", activityType: a.activityType || "peula", description: a.description || "", goals: a.goals || "", materials: a.materials || "", duration: a.duration || "", fileUrl: a.fileUrl || "", fileName: a.fileName || "" });
    setIsOpen(true);
  };

  const handleSubmit = () => {
    const data = { ...form, submittedBy: user?.name || "לא ידוע", date: form.date || null, fileData: form.fileUrl?.startsWith("data:") ? form.fileUrl : null, fileUrl: !form.fileUrl?.startsWith("data:") ? form.fileUrl : null };
    if (editingId) updateActivity.mutate({ id: editingId, data });
    else createActivity.mutate(data);
  };

  const handleFeedback = (a: any) => {
    setFeedbackId(a.id);
    setFeedbackText(a.feedback || "");
    setFeedbackStatus("feedback");
  };

  const submitFeedback = () => {
    if (!feedbackId) return;
    updateActivity.mutate({ id: feedbackId, data: { feedback: feedbackText, feedbackBy: user?.name, feedbackAt: new Date().toISOString(), status: feedbackStatus } });
  };

  const submitActivity = (id: number) => {
    updateActivity.mutate({ id, data: { status: "submitted" } });
  };

  const filtered = (activities as any[]).filter(a => statusFilter === "all" || a.status === statusFilter);
  const viewActivity = (activities as any[]).find(a => a.id === viewId);
  const feedbackActivity = (activities as any[]).find(a => a.id === feedbackId);

  const downloadFile = (a: any) => {
    const url = a.fileData || a.fileUrl;
    if (!url) return;
    const link = document.createElement("a");
    link.href = url;
    link.download = a.fileName || "קובץ";
    link.click();
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-3xl font-bold">הגשת פעולות</h2>
          <p className="text-muted-foreground">הגשה, מעקב ואישור תוכניות פעולות</p>
        </div>
        <Button onClick={() => { setEditingId(null); setForm(EMPTY_FORM); setIsOpen(true); }} className="gap-2">
          <Plus className="w-4 h-4" /> פעולה חדשה
        </Button>
      </div>

      <div className="flex gap-2 flex-wrap">
        {[{ value: "all", label: "הכל" }, ...Object.entries(STATUS_CONFIG).map(([v, c]) => ({ value: v, label: c.label }))].map(({ value, label }) => (
          <button key={value} onClick={() => setStatusFilter(value)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${statusFilter === value ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"}`}>
            {label}
          </button>
        ))}
        <span className="text-sm text-muted-foreground self-center">{filtered.length} פעולות</span>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">טוען...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground border rounded-xl">
          <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="font-medium">אין פעולות עדיין</p>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {filtered.map((a: any) => {
            const cfg = STATUS_CONFIG[a.status] || STATUS_CONFIG.draft;
            const StatusIcon = cfg.icon;
            const typeLabel = ACTIVITY_TYPES.find(t => t.value === a.activityType)?.label || a.activityType;
            const levelLabel = GRADE_LEVELS.find(g => g.value === a.gradeLevel)?.label || a.gradeLevel;
            const hasFile = a.fileData || a.fileUrl;
            return (
              <div key={a.id} className="border rounded-xl p-4 bg-card hover:shadow-sm transition-shadow">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="font-semibold">{a.title}</h3>
                    <p className="text-xs text-muted-foreground">{typeLabel} • {levelLabel}</p>
                  </div>
                  <Badge variant="outline" className={`text-xs flex items-center gap-1 shrink-0 ${cfg.color}`}>
                    <StatusIcon className="w-3 h-3" />{cfg.label}
                  </Badge>
                </div>

                {a.description && <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{a.description}</p>}

                {a.feedback && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5 mb-2 text-sm">
                    <p className="font-medium text-amber-800 text-xs mb-1 flex items-center gap-1">
                      <MessageSquare className="w-3 h-3" /> הערות מ{a.feedbackBy}:
                    </p>
                    <p className="text-amber-700">{a.feedback}</p>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="flex gap-2 text-xs text-muted-foreground">
                    {a.date && <span>{new Date(a.date).toLocaleDateString('he-IL')}</span>}
                    {a.duration && <span>• {a.duration}</span>}
                    {hasFile && <span className="flex items-center gap-0.5"><Paperclip className="w-3 h-3" />{a.fileName || "קובץ"}</span>}
                  </div>
                  <div className="flex gap-1">
                    {hasFile && (
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600" onClick={() => downloadFile(a)} title="הורד קובץ">
                        <Download className="w-3.5 h-3.5" />
                      </Button>
                    )}
                    {a.status === "draft" && (
                      <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => submitActivity(a.id)}>
                        <Send className="w-3 h-3" /> הגש
                      </Button>
                    )}
                    {isPrivileged && a.status === "submitted" && (
                      <Button variant="outline" size="sm" className="h-7 text-xs gap-1 text-amber-700 border-amber-300" onClick={() => handleFeedback(a)}>
                        <MessageSquare className="w-3 h-3" /> הערות
                      </Button>
                    )}
                    {isPrivileged && a.status === "submitted" && (
                      <Button size="sm" className="h-7 text-xs gap-1 bg-green-600 hover:bg-green-700" onClick={() => updateActivity.mutate({ id: a.id, data: { status: "approved" } })}>
                        <CheckCircle2 className="w-3 h-3" /> אשר
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(a)}><Pencil className="w-3.5 h-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => { if (confirm("למחוק?")) deleteActivity.mutate(a.id); }}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>{editingId ? "עריכת פעולה" : "פעולה חדשה"}</DialogTitle></DialogHeader>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto px-1">
            <Input placeholder="כותרת הפעולה *" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
            <div className="grid grid-cols-2 gap-3">
              <Select value={form.activityType} onValueChange={v => setForm(p => ({ ...p, activityType: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ACTIVITY_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={form.gradeLevel} onValueChange={v => setForm(p => ({ ...p, gradeLevel: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{GRADE_LEVELS.map(g => <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground">תאריך</label><Input type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} /></div>
              <div><label className="text-xs text-muted-foreground">משך</label><Input placeholder="שעתיים..." value={form.duration} onChange={e => setForm(p => ({ ...p, duration: e.target.value }))} /></div>
            </div>
            <div><label className="text-sm font-medium">תיאור</label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={3} /></div>
            <div><label className="text-sm font-medium">מטרות</label><Textarea value={form.goals} onChange={e => setForm(p => ({ ...p, goals: e.target.value }))} rows={2} /></div>
            <div><label className="text-sm font-medium">חומרים דרושים</label><Textarea value={form.materials} onChange={e => setForm(p => ({ ...p, materials: e.target.value }))} rows={2} /></div>

            <div className="border rounded-lg p-3 space-y-2">
              <p className="text-sm font-medium flex items-center gap-2"><Paperclip className="w-4 h-4" /> צרף קובץ (PDF, תמונה עד 5MB)</p>
              <input ref={fileRef} type="file" className="hidden" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg" onChange={handleFileChange} />
              <Button variant="outline" size="sm" className="w-full" onClick={() => fileRef.current?.click()} disabled={fileLoading}>
                {fileLoading ? "טוען..." : form.fileName ? `קובץ: ${form.fileName}` : "בחר קובץ"}
              </Button>
              {form.fileName && (
                <Button variant="ghost" size="sm" className="text-destructive text-xs w-full" onClick={() => setForm(p => ({ ...p, fileUrl: "", fileName: "" }))}>
                  הסר קובץ
                </Button>
              )}
            </div>

            <Button className="w-full" onClick={handleSubmit} disabled={!form.title}>
              {editingId ? "שמור" : "שמור כטיוטה"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Feedback Dialog (privileged users) */}
      <Dialog open={!!feedbackId} onOpenChange={() => setFeedbackId(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle>הוסף הערות ל: {feedbackActivity?.title}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <Textarea placeholder="כתוב הערות ותיקונים..." value={feedbackText} onChange={e => setFeedbackText(e.target.value)} rows={4} />
            <div>
              <label className="text-sm font-medium">סטטוס לאחר ההערות</label>
              <Select value={feedbackStatus} onValueChange={setFeedbackStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="feedback">החזר עם הערות</SelectItem>
                  <SelectItem value="approved">אשר עם הערות</SelectItem>
                  <SelectItem value="rejected">דחה</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={submitFeedback} disabled={updateActivity.isPending}>
              שלח הערות
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
