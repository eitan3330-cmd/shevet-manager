import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Check, X, Minus, Search, Users } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const API_BASE = import.meta.env.VITE_API_URL || "";

const STATUS_MAP = {
  present: { label: "נוכח", activeColor: "bg-green-500 text-white border-green-500", color: "text-green-600 border-green-200 hover:bg-green-50", icon: Check },
  late: { label: "איחר", activeColor: "bg-amber-500 text-white border-amber-500", color: "text-amber-600 border-amber-200 hover:bg-amber-50", icon: Minus },
  absent: { label: "נעדר", activeColor: "bg-red-500 text-white border-red-500", color: "text-red-600 border-red-200 hover:bg-red-50", icon: X },
};

const GRADES = ["ד", "ה", "ו", "ז", "ח", "ט", "י", "יא", "יב"];

export function Attendance() {
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [myOnly, setMyOnly] = useState(true);
  const { user, role } = useAuth();
  const qc = useQueryClient();

  const isManager = ["marcaz_boger", "marcaz_tzair"].includes(role || "");

  const { data: scouts = [], isLoading: sl } = useQuery({
    queryKey: ["scouts-raw"],
    queryFn: () => fetch(`${API_BASE}/api/scouts`).then(r => r.json()),
  });

  const { data: attendance = [], isLoading: al } = useQuery({
    queryKey: ["attendance", date],
    queryFn: () => fetch(`${API_BASE}/api/attendance?date=${date}`).then(r => r.json()),
  });

  const markAttendance = useMutation({
    mutationFn: ({ scoutId, status }: { scoutId: number; status: string }) =>
      fetch(`${API_BASE}/api/attendance`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scoutId, date: new Date(date).toISOString(), status }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["attendance", date] }),
  });

  const getStatus = (id: number) => (attendance as any[]).find(r => r.scoutId === id)?.status || null;

  const filtered = (scouts as any[]).filter(s => {
    const name = `${s.name} ${s.lastName || ""}`;
    const matchSearch = !search || name.toLowerCase().includes(search.toLowerCase());
    const matchGrade = gradeFilter === "all" || s.grade === gradeFilter;
    const matchMine = isManager || !myOnly ||
      s.instructorName === user?.name || s.battalion === user?.name || s.gizra === user?.name;
    return matchSearch && matchGrade && matchMine;
  });

  const stats = {
    present: filtered.filter(s => getStatus(s.id) === "present").length,
    late: filtered.filter(s => getStatus(s.id) === "late").length,
    absent: filtered.filter(s => getStatus(s.id) === "absent").length,
    unmarked: filtered.filter(s => !getStatus(s.id)).length,
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-3xl font-bold">נוכחות</h2>
          <p className="text-muted-foreground">{new Date(date).toLocaleDateString("he-IL", { weekday: "long", day: "numeric", month: "long" })}</p>
        </div>
        <Input type="date" className="w-auto" value={date} onChange={e => setDate(e.target.value)} />
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "נוכחים", value: stats.present, color: "text-green-600" },
          { label: "איחרו", value: stats.late, color: "text-amber-600" },
          { label: "נעדרים", value: stats.absent, color: "text-red-600" },
          { label: "לא סומן", value: stats.unmarked, color: "text-muted-foreground" },
        ].map(s => (
          <div key={s.label} className="border rounded-xl p-3 text-center bg-card">
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {filtered.length > 0 && (
        <div className="bg-muted/30 border rounded-xl p-3">
          <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
            <span>כולל {filtered.length} חניכים</span>
            <span className="font-semibold text-green-600">{stats.present + stats.late} נוכחים</span>
          </div>
          <div className="flex h-2 rounded-full overflow-hidden bg-muted">
            <div className="bg-green-500 transition-all" style={{ width: `${(stats.present / filtered.length) * 100}%` }} />
            <div className="bg-amber-500 transition-all" style={{ width: `${(stats.late / filtered.length) * 100}%` }} />
            <div className="bg-red-500 transition-all" style={{ width: `${(stats.absent / filtered.length) * 100}%` }} />
          </div>
        </div>
      )}

      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-40">
          <Search className="absolute right-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input className="pr-9 h-9" placeholder="חיפוש..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={gradeFilter} onValueChange={setGradeFilter}>
          <SelectTrigger className="w-32 h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הכיתות</SelectItem>
            {GRADES.map(g => <SelectItem key={g} value={g}>כיתה {g}</SelectItem>)}
          </SelectContent>
        </Select>
        {!isManager && (
          <button onClick={() => setMyOnly(p => !p)}
            className={`px-3 py-1.5 rounded-lg text-sm border h-9 transition-all ${myOnly ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>
            החניכים שלי
          </button>
        )}
      </div>

      {sl || al ? (
        <div className="text-center py-12 text-muted-foreground">טוען...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground border rounded-xl">
          <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">{myOnly && !isManager ? "אין חניכים משויכים אליך — וודא שהשם שלך מופיע בשדה 'מדריך' בפרופיל החניכים" : "לא נמצאו חניכים"}</p>
        </div>
      ) : (
        <div className="border rounded-xl overflow-hidden bg-card">
          <div className="divide-y divide-border/40">
            {filtered.map((scout: any) => {
              const status = getStatus(scout.id);
              return (
                <div key={scout.id}
                  className={`flex items-center justify-between px-4 py-3 transition-colors ${status === "present" ? "bg-green-50/40" : status === "absent" ? "bg-red-50/40" : status === "late" ? "bg-amber-50/40" : "hover:bg-muted/10"}`}>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium">{scout.name}{scout.lastName ? ` ${scout.lastName}` : ""}</p>
                    <p className="text-xs text-muted-foreground flex gap-2">
                      {scout.grade && <span>כיתה {scout.grade}</span>}
                      {scout.battalion && <span>• {scout.battalion}</span>}
                      {scout.instructorName && <span>• {scout.instructorName}</span>}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {Object.entries(STATUS_MAP).map(([key, cfg]) => {
                      const Icon = cfg.icon;
                      const isActive = status === key;
                      return (
                        <button key={key}
                          onClick={() => markAttendance.mutate({ scoutId: scout.id, status: isActive ? "clear" : key })}
                          className={`h-9 px-3 rounded-lg border text-sm font-medium flex items-center gap-1 transition-all ${isActive ? cfg.activeColor : cfg.color + " bg-transparent"}`}>
                          <Icon className="w-4 h-4" />
                          <span className="hidden sm:inline">{cfg.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
