# מנהל השבט — Scout Manager

  ## התקנה
  ```bash
  npm install
  ```

  ## הגדרת API
  צור קובץ `.env` בתיקיית הפרויקט:
  ```
  VITE_API_URL=https://your-api-server.com
  ```

  ## הפעלה לפיתוח
  ```bash
  npm run dev
  ```

  ## בנייה לייצור
  ```bash
  npm run build
  ```
  