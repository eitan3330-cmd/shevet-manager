import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Role = "marcaz_boger" | "marcaz_tzair" | "roshatz" | "roshgad";

export const ROLE_NAMES: Record<string, string> = {
  marcaz_boger: "מרכז בוגר",
  marcaz_tzair: "מרכז צעיר",
  roshatz: "ראשצ",
  roshgad: "ראשגד",
};

export interface AuthUser {
  id: number;
  name: string;
  role: Role;
}

interface AuthState {
  user: AuthUser | null;
  role: Role | null;
  setUser: (user: AuthUser) => void;
  setRole: (role: Role | null) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      role: null,
      setUser: (user) => set({ user, role: user.role }),
      setRole: (role) => set({ role, user: role ? { id: 0, name: "", role } : null }),
      logout: () => set({ role: null, user: null }),
    }),
    {
      name: "shevet-auth",
    }
  )
);
