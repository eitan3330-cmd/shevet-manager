import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type Role = "marcaz_boger" | "marcaz_tzair" | "roshatz" | "roshgad";

export const ROLE_NAMES: Record<Role, string> = {
  marcaz_boger: "מרכז בוגר",
  marcaz_tzair: "מרכז צעיר",
  roshatz: "ראשצ",
  roshgad: "ראשגד",
};

interface AuthContextType {
  role: Role | null;
  setRole: (role: Role | null) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [role, setRoleState] = useState<Role | null>(() => {
    const saved = localStorage.getItem("shevet-role");
    return saved ? (saved as Role) : null;
  });

  const setRole = (newRole: Role | null) => {
    if (newRole) {
      localStorage.setItem("shevet-role", newRole);
    } else {
      localStorage.removeItem("shevet-role");
    }
    setRoleState(newRole);
  };

  const logout = () => setRole(null);

  return (
    <AuthContext.Provider value={{ role, setRole, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
