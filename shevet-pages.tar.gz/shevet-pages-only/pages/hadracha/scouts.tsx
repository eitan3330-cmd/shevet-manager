import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Search, Users, AlertCircle, Utensils } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";

const API_BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

const GRADES = ["ד", "ה", "ו", "ז", "ח", "ט", "י", "יא", "יב"];

const GRADE_LEVEL_MAP: Record<string, string> = {
  "ד": "חניכים", "ה": "חניכים", "ו": "חניכים",
  "ז": "חניכים בכירים", "ח": "חניכים בכירים",
  "ט": "שכבה ט",
  "י": "פעילים", "יא": "פעילים", "יב": "פעילים",
};

const GIZRA_OPTIONS = ["גדוד א", "גדוד ב", "גדוד ג", "גדוד ד", "גדוד ה", "לוגיסטיקה", "קהילה", "מטה"];

type ScoutForm = {
  name: string; lastName: string; phone: string; gizra: string; battalion: string;
  instructorName: string; grade: string; foodPreferences: string; medicalIssues: string; notes: string;
};
const EMPTY: ScoutForm = { name: "", lastName: "", phone: "", gizra: "", battalion: "", instructorName: "", grade: "", foodPreferences: "", medicalIssues: "", notes: "" };

export function Scouts() {
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [gizraFilter, setGizraFilter] = useState("all");
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<ScoutForm>(EMPTY);
  const [tab, setTab] = useState<"list" | "medical" | "food">("list");
  const { toast } = useToast();
  const { role } = useAuth();
  const qc = useQueryClient();

  const { data: scouts = [], isLoading } = useQuery({
    queryKey: ["scouts-raw"],
    queryFn: () => fetch(`${API_BASE}/api/scouts`).then(r => r.json()),
  });

  const createScout = useMutation({
    mutationFn: (data: any) => fetch(`${API_BASE}/api/scouts`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["scouts-raw"] }); setIsOpen(false); setForm(EMPTY); toast({ title: "חניך נוסף" }); },
  });

  const updateScout = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => fetch(`${API_BASE}/api/scouts/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["scouts-raw"] }); setIsOpen(false); toast({ title: "חניך עודכן" }); },
  });

  const deleteScout = useMutation({
    mutationFn: (id: number) => fetch(`${API_BASE}/api/scouts/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["scouts-raw"] }); toast({ title: "חניך נמחק" }); },
  });

  const handleEdit = (s: any) => {
    setEditId(s.id);
    setForm({ name: s.name || "", lastName: s.lastName || "", phone: s.phone || "", gizra: s.gizra || "", battalion: s.battalion || "", instructorName: s.instructorName || "", grade: s.grade || "", foodPreferences: s.foodPreferences || "", medicalIssues: s.medicalIssues || "", notes: s.notes || "" });
    setIsOpen(true);
  };

  const handleSubmit = () => {
    if (!form.name || !form.gizra) return;
    const gradeLevel = form.grade ? GRADE_LEVEL_MAP[form.grade] || null : null;
    const data = { ...form, gradeLevel, role: "chanich", tribeRole: null, parentPhone: null };
    if (editId) updateScout.mutate({ id: editId, data });
    else createScout.mutate(data);
  };

  const canEdit = ["marcaz_boger", "marcaz_tzair"].includes(role || "");

  const filtered = (scouts as any[]).filter(s => {
    const matchSearch = !search || `${s.name} ${s.lastName || ""}`.includes(search);
    const matchGrade = gradeFilter === "all" || s.grade === gradeFilter;
    const matchGizra = gizraFilter === "all" || s.gizra === gizraFilter;
    return matchSearch && matchGrade && matchGizra;
  });

  const gizras = [...new Set((scouts as any[]).map(s => s.gizra).filter(Boolean))];

  const withMedical = filtered.filter(s => s.medicalIssues);
  const withFood = filtered.filter(s => s.foodPreferences);

  const groupByGrade: Record<string, any[]> = {};
  filtered.forEach(s => {
    const level = s.grade ? GRADE_LEVEL_MAP[s.grade] || "אחר" : "ללא כיתה";
    if (!groupByGrade[level]) groupByGrade[level] = [];
    groupByGrade[level].push(s);
  });

  const gradeOrder = ["פעילים", "שכבה ט", "חניכים בכירים", "חניכים", "ללא כיתה", "אחר"];

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-3xl font-bold">מאגר חניכים</h2>
          <p className="text-muted-foreground">{(scouts as any[]).length} חניכים במאגר</p>
        </div>
        {canEdit && (
          <Button onClick={() => { setEditId(null); setForm(EMPTY); setIsOpen(true); }} className="gap-2">
            <Plus className="w-4 h-4" /> חניך חדש
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "סה״כ חניכים", value: (scouts as any[]).length },
          { label: "פעילים י-יב", value: (scouts as any[]).filter(s => ["י", "יא", "יב"].includes(s.grade)).length, color: "text-blue-600" },
          { label: "בעיות רפואיות", value: (scouts as any[]).filter(s => s.medicalIssues).length, color: "text-red-600" },
          { label: "העדפות מזון", value: (scouts as any[]).filter(s => s.foodPreferences).length, color: "text-amber-600" },
        ].map(s => (
          <Card key={s.label}><CardContent className="pt-4 pb-3 text-center">
            <p className={`text-2xl font-bold ${s.color || ""}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </CardContent></Card>
        ))}
      </div>

      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute right-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input className="pr-9" placeholder="חיפוש לפי שם..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={gradeFilter} onValueChange={setGradeFilter}>
          <SelectTrigger className="w-32 h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הכיתות</SelectItem>
            {GRADES.map(g => <SelectItem key={g} value={g}>כיתה {g}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={gizraFilter} onValueChange={setGizraFilter}>
          <SelectTrigger className="w-36 h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">כל הגזרות</SelectItem>
            {gizras.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="flex gap-1.5">
        {[{ id: "list", label: "רשימה" }, { id: "medical", label: `בעיות רפואיות (${withMedical.length})` }, { id: "food", label: `העדפות מזון (${withFood.length})` }].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${tab === t.id ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 rounded-lg" />)}</div>
      ) : tab === "medical" ? (
        <div className="space-y-2">
          {withMedical.length === 0 ? <p className="text-center py-8 text-muted-foreground">אין חניכים עם בעיות רפואיות</p> : withMedical.map((s: any) => (
            <div key={s.id} className="border rounded-xl p-3 bg-red-50/50 border-red-100 flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold">{s.name} {s.lastName || ""}</p>
                <p className="text-xs text-muted-foreground">{s.gizra} • {s.grade ? `כיתה ${s.grade}` : ""} {s.instructorName ? `• מדריך: ${s.instructorName}` : ""}</p>
                <p className="text-sm text-red-700 flex items-center gap-1 mt-1"><AlertCircle className="w-3.5 h-3.5" />{s.medicalIssues}</p>
              </div>
            </div>
          ))}
        </div>
      ) : tab === "food" ? (
        <div className="space-y-2">
          {withFood.length === 0 ? <p className="text-center py-8 text-muted-foreground">אין חניכים עם העדפות מזון מיוחדות</p> : withFood.map((s: any) => (
            <div key={s.id} className="border rounded-xl p-3 bg-amber-50/50 border-amber-100 flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold">{s.name} {s.lastName || ""}</p>
                <p className="text-xs text-muted-foreground">{s.gizra} • {s.grade ? `כיתה ${s.grade}` : ""}</p>
                <p className="text-sm text-amber-700 flex items-center gap-1 mt-1"><Utensils className="w-3.5 h-3.5" />{s.foodPreferences}</p>
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground border rounded-xl">
          <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>לא נמצאו חניכים</p>
        </div>
      ) : (
        <div className="space-y-4">
          {gradeOrder.filter(level => groupByGrade[level]?.length > 0).map(level => (
            <div key={level}>
              <h3 className="text-sm font-semibold text-muted-foreground mb-2 flex items-center gap-2">
                <span className="px-2 py-0.5 bg-muted rounded-md">{level}</span>
                <span>({groupByGrade[level].length})</span>
              </h3>
              <div className="border rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted/30">
                    <tr>
                      <th className="text-right p-3 font-medium">שם</th>
                      <th className="text-right p-3 font-medium hidden md:table-cell">שם משפחה</th>
                      <th className="text-right p-3 font-medium">כיתה</th>
                      <th className="text-right p-3 font-medium hidden md:table-cell">גדוד</th>
                      <th className="text-right p-3 font-medium hidden md:table-cell">מדריך</th>
                      <th className="text-right p-3 font-medium hidden lg:table-cell">גזרה</th>
                      <th className="p-3 w-8" />
                    </tr>
                  </thead>
                  <tbody>
                    {groupByGrade[level].map((s: any, i: number) => (
                      <tr key={s.id} className={`${i % 2 === 0 ? "bg-background" : "bg-muted/10"} hover:bg-muted/20 transition-colors`}>
                        <td className="p-3 font-medium">
                          {s.name}
                          {s.medicalIssues && <AlertCircle className="w-3.5 h-3.5 inline mr-1 text-red-500" title={s.medicalIssues} />}
                          {s.foodPreferences && <Utensils className="w-3.5 h-3.5 inline mr-1 text-amber-500" title={s.foodPreferences} />}
                        </td>
                        <td className="p-3 text-muted-foreground hidden md:table-cell">{s.lastName || "—"}</td>
                        <td className="p-3">{s.grade ? `כיתה ${s.grade}` : "—"}</td>
                        <td className="p-3 text-muted-foreground hidden md:table-cell">{s.battalion || "—"}</td>
                        <td className="p-3 text-muted-foreground hidden md:table-cell">{s.instructorName || "—"}</td>
                        <td className="p-3 text-muted-foreground hidden lg:table-cell">{s.gizra}</td>
                        <td className="p-3">
                          {canEdit && (
                            <div className="flex gap-1">
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(s)}><Pencil className="w-3.5 h-3.5" /></Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => { if (confirm("למחוק?")) deleteScout.mutate(s.id); }}><Trash2 className="w-3.5 h-3.5" /></Button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>{editId ? "עריכת חניך" : "חניך חדש"}</DialogTitle></DialogHeader>
          <div className="space-y-3 max-h-[75vh] overflow-y-auto px-1">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground">שם פרטי *</label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
              <div><label className="text-xs text-muted-foreground">שם משפחה</label><Input value={form.lastName} onChange={e => setForm(p => ({ ...p, lastName: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">גזרה *</label>
                <Select value={form.gizra || "manual"} onValueChange={v => setForm(p => ({ ...p, gizra: v === "manual" ? "" : v }))}>
                  <SelectTrigger><SelectValue placeholder="בחר גזרה" /></SelectTrigger>
                  <SelectContent>
                    {GIZRA_OPTIONS.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                    <SelectItem value="manual">אחר</SelectItem>
                  </SelectContent>
                </Select>
                {form.gizra && !GIZRA_OPTIONS.includes(form.gizra) && (
                  <Input className="mt-1" placeholder="הזן גזרה ידנית" value={form.gizra} onChange={e => setForm(p => ({ ...p, gizra: e.target.value }))} />
                )}
              </div>
              <div>
                <label className="text-xs text-muted-foreground">כיתה</label>
                <Select value={form.grade || "none"} onValueChange={v => setForm(p => ({ ...p, grade: v === "none" ? "" : v }))}>
                  <SelectTrigger><SelectValue placeholder="בחר כיתה" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">ללא</SelectItem>
                    {GRADES.map(g => <SelectItem key={g} value={g}>כיתה {g}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs text-muted-foreground">גדוד</label><Input placeholder="גדוד כ..." value={form.battalion} onChange={e => setForm(p => ({ ...p, battalion: e.target.value }))} /></div>
              <div><label className="text-xs text-muted-foreground">מדריך</label><Input placeholder="שם המדריך" value={form.instructorName} onChange={e => setForm(p => ({ ...p, instructorName: e.target.value }))} /></div>
            </div>
            <div><label className="text-xs text-muted-foreground">טלפון</label><Input type="tel" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
            <div>
              <label className="text-sm font-medium flex items-center gap-1"><Utensils className="w-3.5 h-3.5 text-amber-500" />העדפות מזון / רגישויות</label>
              <Input placeholder="צמחוני, אלרגיה לאגוזים..." value={form.foodPreferences} onChange={e => setForm(p => ({ ...p, foodPreferences: e.target.value }))} />
            </div>
            <div>
              <label className="text-sm font-medium flex items-center gap-1"><AlertCircle className="w-3.5 h-3.5 text-red-500" />בעיות רפואיות</label>
              <Textarea placeholder="אסטמה, סכרת, תרופות..." value={form.medicalIssues} onChange={e => setForm(p => ({ ...p, medicalIssues: e.target.value }))} rows={2} />
            </div>
            <div><label className="text-sm font-medium">הערות</label><Textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={2} /></div>
            <Button className="w-full" onClick={handleSubmit} disabled={!form.name || !form.gizra}>
              {editId ? "שמור שינויים" : "הוסף חניך"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
