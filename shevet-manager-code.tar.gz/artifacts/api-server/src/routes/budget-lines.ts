import { Router } from "express";
import { db } from "@workspace/db";
import { budgetLinesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/budget-lines", async (req, res) => {
  const { year } = req.query;
  let lines = await db.select().from(budgetLinesTable).orderBy(budgetLinesTable.category);
  if (year) lines = lines.filter(l => l.yearLabel === year);
  res.json(lines.map(l => ({
    ...l,
    allocatedAmount: parseFloat(l.allocatedAmount),
    spentAmount: parseFloat(l.spentAmount),
    lastYearAmount: l.lastYearAmount ? parseFloat(l.lastYearAmount) : null,
  })));
});

router.post("/budget-lines", async (req, res) => {
  const { yearLabel, category, description, allocatedAmount, spentAmount, lastYearAmount, notes } = req.body;
  if (!yearLabel || !category) return res.status(400).json({ error: "שנה וקטגוריה חובה" });
  const [line] = await db.insert(budgetLinesTable).values({
    yearLabel, category, description, notes,
    allocatedAmount: String(allocatedAmount || 0),
    spentAmount: String(spentAmount || 0),
    lastYearAmount: lastYearAmount != null ? String(lastYearAmount) : null,
  }).returning();
  res.status(201).json({ ...line, allocatedAmount: parseFloat(line.allocatedAmount), spentAmount: parseFloat(line.spentAmount) });
});

router.put("/budget-lines/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { yearLabel, category, description, allocatedAmount, spentAmount, lastYearAmount, notes } = req.body;
  const [line] = await db.update(budgetLinesTable).set({
    yearLabel, category, description, notes,
    allocatedAmount: String(allocatedAmount || 0),
    spentAmount: String(spentAmount || 0),
    lastYearAmount: lastYearAmount != null ? String(lastYearAmount) : null,
    updatedAt: new Date(),
  }).where(eq(budgetLinesTable.id, id)).returning();
  res.json({ ...line, allocatedAmount: parseFloat(line.allocatedAmount), spentAmount: parseFloat(line.spentAmount) });
});

router.delete("/budget-lines/:id", async (req, res) => {
  await db.delete(budgetLinesTable).where(eq(budgetLinesTable.id, parseInt(req.params.id)));
  res.sendStatus(204);
});

export default router;
