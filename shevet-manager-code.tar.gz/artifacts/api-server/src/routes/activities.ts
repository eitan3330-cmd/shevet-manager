import { Router } from "express";
import { db } from "@workspace/db";
import { activitiesTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/activities", async (req, res) => {
  const activities = await db.select().from(activitiesTable).orderBy(desc(activitiesTable.createdAt));
  res.json(activities);
});

router.get("/activities/:id", async (req, res) => {
  const [activity] = await db.select().from(activitiesTable).where(eq(activitiesTable.id, parseInt(req.params.id)));
  if (!activity) return res.status(404).json({ error: "לא נמצא" });
  res.json(activity);
});

router.post("/activities", async (req, res) => {
  const { title, date, gradeLevel, activityType, description, goals, materials, duration, submittedBy, fileUrl, fileName, fileData } = req.body;
  if (!title) return res.status(400).json({ error: "כותרת חובה" });
  const [activity] = await db.insert(activitiesTable).values({
    title, gradeLevel, activityType: activityType || "peula",
    description, goals, materials, duration, submittedBy,
    fileUrl: fileUrl || null, fileName: fileName || null, fileData: fileData || null,
    date: date ? new Date(date) : null,
    status: "draft",
  }).returning();
  res.status(201).json(activity);
});

router.put("/activities/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const {
    title, date, gradeLevel, activityType, description, goals, materials, duration,
    status, feedback, feedbackBy, feedbackAt, submittedBy, fileUrl, fileName, fileData,
  } = req.body;

  const updates: Record<string, unknown> = { updatedAt: new Date() };
  if (title !== undefined) updates.title = title;
  if (gradeLevel !== undefined) updates.gradeLevel = gradeLevel;
  if (activityType !== undefined) updates.activityType = activityType;
  if (description !== undefined) updates.description = description;
  if (goals !== undefined) updates.goals = goals;
  if (materials !== undefined) updates.materials = materials;
  if (duration !== undefined) updates.duration = duration;
  if (status !== undefined) updates.status = status;
  if (feedback !== undefined) updates.feedback = feedback;
  if (feedbackBy !== undefined) updates.feedbackBy = feedbackBy;
  if (feedbackAt !== undefined) updates.feedbackAt = feedbackAt ? new Date(feedbackAt) : null;
  if (submittedBy !== undefined) updates.submittedBy = submittedBy;
  if (fileUrl !== undefined) updates.fileUrl = fileUrl;
  if (fileName !== undefined) updates.fileName = fileName;
  if (fileData !== undefined) updates.fileData = fileData;
  if (date !== undefined) updates.date = date ? new Date(date) : null;

  const [activity] = await db.update(activitiesTable).set(updates).where(eq(activitiesTable.id, id)).returning();
  res.json(activity);
});

router.delete("/activities/:id", async (req, res) => {
  await db.delete(activitiesTable).where(eq(activitiesTable.id, parseInt(req.params.id)));
  res.sendStatus(204);
});

export default router;
