import { Router } from "express";
import { eq, desc } from "drizzle-orm";
import { db, procurementTable } from "@workspace/db";

const router = Router();

function parseOrder(order: any) {
  return { ...order, amount: order.amount ? parseFloat(order.amount) : 0 };
}

router.get("/procurement", async (req, res) => {
  const { status, categoryId } = req.query as { status?: string; categoryId?: string };
  let orders = await db.select().from(procurementTable).orderBy(desc(procurementTable.createdAt));
  if (status) orders = orders.filter(o => o.status === status);
  if (categoryId) orders = orders.filter(o => o.categoryId === parseInt(categoryId));
  res.json(orders.map(parseOrder));
});

router.post("/procurement", async (req, res) => {
  const { title, description, amount, supplier, contactPhone, status, orderType, categoryId, eventId, requestedBy, approvedBy, itemsDetail, quoteNotes, fileUrl, fileName, expectedDelivery, data } = req.body;
  const payload = data || req.body;
  if (!payload.title) return res.status(400).json({ error: "כותרת חובה" });
  const [order] = await db.insert(procurementTable).values({
    title: payload.title,
    description: payload.description || null,
    amount: String(payload.amount || "0"),
    supplier: payload.supplier || null,
    contactPhone: payload.contactPhone || null,
    status: payload.status || "pending",
    orderType: payload.orderType || "order",
    categoryId: payload.categoryId ? parseInt(String(payload.categoryId)) : null,
    eventId: payload.eventId || null,
    requestedBy: payload.requestedBy || null,
    approvedBy: payload.approvedBy || null,
    itemsDetail: payload.itemsDetail || null,
    quoteNotes: payload.quoteNotes || null,
    fileUrl: payload.fileUrl || null,
    fileName: payload.fileName || null,
    expectedDelivery: payload.expectedDelivery ? new Date(payload.expectedDelivery) : null,
  }).returning();
  res.status(201).json(parseOrder(order));
});

router.put("/procurement/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { title, description, amount, supplier, contactPhone, status, orderType, categoryId, requestedBy, approvedBy, itemsDetail, quoteNotes, fileUrl, fileName, expectedDelivery } = req.body;
  const updates: any = {};
  if (title !== undefined) updates.title = title;
  if (description !== undefined) updates.description = description;
  if (amount !== undefined) updates.amount = String(amount);
  if (supplier !== undefined) updates.supplier = supplier;
  if (contactPhone !== undefined) updates.contactPhone = contactPhone;
  if (status !== undefined) updates.status = status;
  if (orderType !== undefined) updates.orderType = orderType;
  if (categoryId !== undefined) updates.categoryId = categoryId ? parseInt(String(categoryId)) : null;
  if (requestedBy !== undefined) updates.requestedBy = requestedBy;
  if (approvedBy !== undefined) updates.approvedBy = approvedBy;
  if (itemsDetail !== undefined) updates.itemsDetail = itemsDetail;
  if (quoteNotes !== undefined) updates.quoteNotes = quoteNotes;
  if (fileUrl !== undefined) updates.fileUrl = fileUrl;
  if (fileName !== undefined) updates.fileName = fileName;
  if (expectedDelivery !== undefined) updates.expectedDelivery = expectedDelivery ? new Date(expectedDelivery) : null;
  const [order] = await db.update(procurementTable).set(updates).where(eq(procurementTable.id, id)).returning();
  if (!order) return res.status(404).json({ error: "לא נמצא" });
  res.json(parseOrder(order));
});

router.patch("/procurement/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const updates: any = {};
  for (const [k, v] of Object.entries(req.body)) {
    if (v !== null && v !== undefined) {
      updates[k] = k === "amount" ? String(v) : v;
    }
  }
  const [order] = await db.update(procurementTable).set(updates).where(eq(procurementTable.id, id)).returning();
  if (!order) return res.status(404).json({ error: "לא נמצא" });
  res.json(parseOrder(order));
});

router.delete("/procurement/:id", async (req, res) => {
  await db.delete(procurementTable).where(eq(procurementTable.id, parseInt(req.params.id)));
  res.sendStatus(204);
});

export default router;
