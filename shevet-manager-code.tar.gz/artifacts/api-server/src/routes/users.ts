import { Router } from "express";
import { db } from "@workspace/db";
import { tribeUsersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/users", async (_req, res) => {
  try {
    const users = await db.select().from(tribeUsersTable).where(eq(tribeUsersTable.active, true)).orderBy(tribeUsersTable.name);
    res.json(users);
  } catch {
    res.status(500).json({ error: "שגיאה בטעינת משתמשים" });
  }
});

router.post("/users", async (req, res) => {
  try {
    const { name, role } = req.body;
    if (!name || !role) return res.status(400).json({ error: "שם ותפקיד חובה" });
    const [user] = await db.insert(tribeUsersTable).values({ name, role, active: true }).returning();
    res.status(201).json(user);
  } catch {
    res.status(500).json({ error: "שגיאה ביצירת משתמש" });
  }
});

router.delete("/users/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.update(tribeUsersTable).set({ active: false }).where(eq(tribeUsersTable.id, id));
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: "שגיאה במחיקת משתמש" });
  }
});

router.delete("/users", async (_req, res) => {
  try {
    await db.update(tribeUsersTable).set({ active: false });
    res.json({ success: true, message: "כל המשתמשים אופסו" });
  } catch {
    res.status(500).json({ error: "שגיאה באיפוס משתמשים" });
  }
});

export default router;
