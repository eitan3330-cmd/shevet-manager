import { Router } from "express";
import { eq, asc } from "drizzle-orm";
import { db, scoutsTable } from "@workspace/db";

const router = Router();

router.get("/scouts", async (req, res) => {
  const { gizra, role, battalion, instructorName } = req.query as Record<string, string>;
  let scouts = await db.select().from(scoutsTable).orderBy(asc(scoutsTable.name));
  if (gizra) scouts = scouts.filter(s => s.gizra === gizra);
  if (role) scouts = scouts.filter(s => s.role === role);
  if (battalion) scouts = scouts.filter(s => s.battalion === battalion);
  if (instructorName) scouts = scouts.filter(s => s.instructorName === instructorName);
  res.json(scouts);
});

router.post("/scouts", async (req, res) => {
  const { name, lastName, phone, parentPhone, gizra, battalion, instructorName, grade, gradeLevel, tribeRole, role, foodPreferences, medicalIssues, notes } = req.body;
  if (!name || !gizra) return res.status(400).json({ error: "שם וגזרה חובה" });
  const [scout] = await db.insert(scoutsTable).values({
    name, lastName: lastName || null, phone: phone || null, parentPhone: parentPhone || null,
    gizra, battalion: battalion || null, instructorName: instructorName || null,
    grade: grade || null, gradeLevel: gradeLevel || null, tribeRole: tribeRole || null,
    role: role || "chanich", foodPreferences: foodPreferences || null,
    medicalIssues: medicalIssues || null, notes: notes || null,
  }).returning();
  res.status(201).json(scout);
});

router.get("/scouts/:id", async (req, res) => {
  const [scout] = await db.select().from(scoutsTable).where(eq(scoutsTable.id, parseInt(req.params.id)));
  if (!scout) return res.status(404).json({ error: "לא נמצא" });
  res.json(scout);
});

router.patch("/scouts/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const { name, lastName, phone, parentPhone, gizra, battalion, instructorName, grade, gradeLevel, tribeRole, role, foodPreferences, medicalIssues, notes } = req.body;
  const updates: Record<string, unknown> = {};
  if (name !== undefined) updates.name = name;
  if (lastName !== undefined) updates.lastName = lastName;
  if (phone !== undefined) updates.phone = phone;
  if (parentPhone !== undefined) updates.parentPhone = parentPhone;
  if (gizra !== undefined) updates.gizra = gizra;
  if (battalion !== undefined) updates.battalion = battalion;
  if (instructorName !== undefined) updates.instructorName = instructorName;
  if (grade !== undefined) updates.grade = grade;
  if (gradeLevel !== undefined) updates.gradeLevel = gradeLevel;
  if (tribeRole !== undefined) updates.tribeRole = tribeRole;
  if (role !== undefined) updates.role = role;
  if (foodPreferences !== undefined) updates.foodPreferences = foodPreferences;
  if (medicalIssues !== undefined) updates.medicalIssues = medicalIssues;
  if (notes !== undefined) updates.notes = notes;
  const [scout] = await db.update(scoutsTable).set(updates).where(eq(scoutsTable.id, id)).returning();
  if (!scout) return res.status(404).json({ error: "לא נמצא" });
  res.json(scout);
});

router.delete("/scouts/:id", async (req, res) => {
  await db.delete(scoutsTable).where(eq(scoutsTable.id, parseInt(req.params.id)));
  res.sendStatus(204);
});

export default router;
