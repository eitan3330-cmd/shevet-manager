import { Router } from "express";
import { db } from "@workspace/db";
import { eventTasksTable, eventParticipantsTable, eventBusesTable, eventMenuTable, scoutsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

/* ---- TASKS ---- */
router.get("/events/:id/tasks", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const tasks = await db.select().from(eventTasksTable).where(eq(eventTasksTable.eventId, eventId)).orderBy(eventTasksTable.createdAt);
  res.json(tasks);
});
router.post("/events/:id/tasks", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const { title, priority, assignee, notes, dueDate } = req.body;
  if (!title) return res.status(400).json({ error: "כותרת חובה" });
  const [task] = await db.insert(eventTasksTable).values({ eventId, title, priority: priority || "normal", assignee, notes, dueDate: dueDate ? new Date(dueDate) : null }).returning();
  res.status(201).json(task);
});
router.patch("/events/:id/tasks/:taskId", async (req, res) => {
  const taskId = parseInt(req.params.taskId);
  const { done, title, priority, assignee, notes } = req.body;
  const [task] = await db.update(eventTasksTable).set({ done, title, priority, assignee, notes }).where(eq(eventTasksTable.id, taskId)).returning();
  res.json(task);
});
router.delete("/events/:id/tasks/:taskId", async (req, res) => {
  await db.delete(eventTasksTable).where(eq(eventTasksTable.id, parseInt(req.params.taskId)));
  res.sendStatus(204);
});

/* ---- PARTICIPANTS ---- */
router.get("/events/:id/participants", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const participants = await db
    .select({
      id: eventParticipantsTable.id,
      eventId: eventParticipantsTable.eventId,
      scoutId: eventParticipantsTable.scoutId,
      status: eventParticipantsTable.status,
      busId: eventParticipantsTable.busId,
      notes: eventParticipantsTable.notes,
      scoutName: scoutsTable.name,
      scoutGrade: scoutsTable.grade,
      scoutGizra: scoutsTable.gizra,
      scoutPhone: scoutsTable.phone,
    })
    .from(eventParticipantsTable)
    .leftJoin(scoutsTable, eq(eventParticipantsTable.scoutId, scoutsTable.id))
    .where(eq(eventParticipantsTable.eventId, eventId));
  res.json(participants);
});
router.post("/events/:id/participants", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const { scoutId, status, busId, notes } = req.body;
  if (!scoutId) return res.status(400).json({ error: "חניך חובה" });
  const [p] = await db.insert(eventParticipantsTable).values({ eventId, scoutId, status: status || "confirmed", busId, notes }).returning();
  res.status(201).json(p);
});
router.delete("/events/:id/participants/:pid", async (req, res) => {
  await db.delete(eventParticipantsTable).where(eq(eventParticipantsTable.id, parseInt(req.params.pid)));
  res.sendStatus(204);
});

/* ---- BUSES ---- */
router.get("/events/:id/buses", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const buses = await db.select().from(eventBusesTable).where(eq(eventBusesTable.eventId, eventId)).orderBy(eventBusesTable.createdAt);
  res.json(buses);
});
router.post("/events/:id/buses", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const { name, capacity, driverName, departureTime, meetingPoint, notes } = req.body;
  if (!name) return res.status(400).json({ error: "שם אוטובוס חובה" });
  const [bus] = await db.insert(eventBusesTable).values({ eventId, name, capacity, driverName, departureTime, meetingPoint, notes }).returning();
  res.status(201).json(bus);
});
router.patch("/events/:id/buses/:busId", async (req, res) => {
  const busId = parseInt(req.params.busId);
  const [bus] = await db.update(eventBusesTable).set(req.body).where(eq(eventBusesTable.id, busId)).returning();
  res.json(bus);
});
router.delete("/events/:id/buses/:busId", async (req, res) => {
  await db.delete(eventBusesTable).where(eq(eventBusesTable.id, parseInt(req.params.busId)));
  res.sendStatus(204);
});

/* ---- MENU ---- */
router.get("/events/:id/menu", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const menu = await db.select().from(eventMenuTable).where(eq(eventMenuTable.eventId, eventId)).orderBy(eventMenuTable.dayNumber, eventMenuTable.createdAt);
  res.json(menu);
});
router.post("/events/:id/menu", async (req, res) => {
  const eventId = parseInt(req.params.id);
  const { dayNumber, mealType, description, notes } = req.body;
  if (!mealType || !description) return res.status(400).json({ error: "סוג ארוחה ותיאור חובה" });
  const [item] = await db.insert(eventMenuTable).values({ eventId, dayNumber: dayNumber || 1, mealType, description, notes }).returning();
  res.status(201).json(item);
});
router.patch("/events/:id/menu/:menuId", async (req, res) => {
  const menuId = parseInt(req.params.menuId);
  const [item] = await db.update(eventMenuTable).set(req.body).where(eq(eventMenuTable.id, menuId)).returning();
  res.json(item);
});
router.delete("/events/:id/menu/:menuId", async (req, res) => {
  await db.delete(eventMenuTable).where(eq(eventMenuTable.id, parseInt(req.params.menuId)));
  res.sendStatus(204);
});

export default router;
