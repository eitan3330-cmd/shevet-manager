import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowRight, Plus, Trash2, CheckCircle2, Circle, CalendarRange,
  MapPin, User, Users, Bus, Utensils, ListTodo, Pencil,
  AlertCircle, Clock, ChevronDown
} from "lucide-react";
import { useListScouts } from "@workspace/api-client-react";

const API_BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";
const apiFetch = (path: string, opts?: RequestInit) =>
  fetch(`${API_BASE}/api${path}`, opts).then(r => r.json());

const MEAL_TYPES = [
  { value: "breakfast", label: "ארוחת בוקר" },
  { value: "lunch", label: "ארוחת צהריים" },
  { value: "dinner", label: "ארוחת ערב" },
  { value: "snack", label: "חטיף" },
];

const EVENT_TYPES: Record<string, string> = {
  shabaton: "שבתון", mifaal_yomi: "מפעל יומי", erev: "ערב",
  machaneh_kayitz: "מחנה קיץ", machaneh_choref: "מחנה חורף",
  tiyul: "טיול", peilut_shvatit: "פעילות שבטית", akira: "עקירה", other: "אחר",
};

const PRIORITY_CONFIG: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  high: { label: "דחוף", color: "text-red-600 bg-red-50 border-red-200", icon: AlertCircle },
  normal: { label: "רגיל", color: "text-blue-600 bg-blue-50 border-blue-200", icon: Clock },
  low: { label: "נמוך", color: "text-slate-500 bg-slate-50 border-slate-200", icon: Circle },
};

type Tab = "details" | "tasks" | "participants" | "buses" | "menu";

export function EventWorkspace() {
  const [, params] = useRoute("/logistics/events/:id");
  const [, setLocation] = useLocation();
  const eventId = params?.id ? parseInt(params.id) : null;
  const [activeTab, setActiveTab] = useState<Tab>("tasks");
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: event, isLoading: eventLoading } = useQuery({
    queryKey: ["event", eventId],
    queryFn: () => apiFetch(`/events/${eventId}`),
    enabled: !!eventId,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ["event-tasks", eventId],
    queryFn: () => apiFetch(`/events/${eventId}/tasks`),
    enabled: !!eventId,
  });

  const { data: participants = [] } = useQuery({
    queryKey: ["event-participants", eventId],
    queryFn: () => apiFetch(`/events/${eventId}/participants`),
    enabled: !!eventId,
  });

  const { data: buses = [] } = useQuery({
    queryKey: ["event-buses", eventId],
    queryFn: () => apiFetch(`/events/${eventId}/buses`),
    enabled: !!eventId,
  });

  const { data: menu = [] } = useQuery({
    queryKey: ["event-menu", eventId],
    queryFn: () => apiFetch(`/events/${eventId}/menu`),
    enabled: !!eventId,
  });

  const { data: allScouts = [] } = useListScouts();

  const invalidate = (key: string) => qc.invalidateQueries({ queryKey: [key, eventId] });

  // --- Tasks ---
  const [newTask, setNewTask] = useState("");
  const [taskPriority, setTaskPriority] = useState("normal");
  const [taskAssignee, setTaskAssignee] = useState("");

  const addTask = useMutation({
    mutationFn: (data: any) => fetch(`${API_BASE}/api/events/${eventId}/tasks`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { invalidate("event-tasks"); setNewTask(""); setTaskAssignee(""); },
  });

  const toggleTask = useMutation({
    mutationFn: ({ taskId, done }: { taskId: number; done: boolean }) =>
      fetch(`${API_BASE}/api/events/${eventId}/tasks/${taskId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ done }) }).then(r => r.json()),
    onSuccess: () => invalidate("event-tasks"),
  });

  const deleteTask = useMutation({
    mutationFn: (taskId: number) => fetch(`${API_BASE}/api/events/${eventId}/tasks/${taskId}`, { method: "DELETE" }),
    onSuccess: () => invalidate("event-tasks"),
  });

  // --- Participants ---
  const [selectedScout, setSelectedScout] = useState("");
  const addParticipant = useMutation({
    mutationFn: (scoutId: number) => fetch(`${API_BASE}/api/events/${eventId}/participants`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ scoutId }) }).then(r => r.json()),
    onSuccess: () => { invalidate("event-participants"); setSelectedScout(""); },
    onError: () => toast({ title: "שגיאה בהוספת משתתף", variant: "destructive" }),
  });
  const removeParticipant = useMutation({
    mutationFn: (pid: number) => fetch(`${API_BASE}/api/events/${eventId}/participants/${pid}`, { method: "DELETE" }),
    onSuccess: () => invalidate("event-participants"),
  });

  const assignBusToParticipant = useMutation({
    mutationFn: ({ pid, busId }: { pid: number; busId: number | null }) =>
      fetch(`${API_BASE}/api/events/${eventId}/participants/${pid}`, { method: "DELETE" }).then(() => Promise.resolve()),
    onSuccess: () => invalidate("event-participants"),
  });

  // --- Buses ---
  const [newBus, setNewBus] = useState({ name: "", capacity: "", driverName: "", departureTime: "", meetingPoint: "" });
  const addBus = useMutation({
    mutationFn: () => fetch(`${API_BASE}/api/events/${eventId}/buses`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...newBus, capacity: newBus.capacity ? parseInt(newBus.capacity) : null }) }).then(r => r.json()),
    onSuccess: () => { invalidate("event-buses"); setNewBus({ name: "", capacity: "", driverName: "", departureTime: "", meetingPoint: "" }); },
  });
  const deleteBus = useMutation({
    mutationFn: (busId: number) => fetch(`${API_BASE}/api/events/${eventId}/buses/${busId}`, { method: "DELETE" }),
    onSuccess: () => invalidate("event-buses"),
  });

  // --- Menu ---
  const [selectedDay, setSelectedDay] = useState(1);
  const [newMenuItem, setNewMenuItem] = useState({ mealType: "breakfast", description: "" });
  const addMenuItem = useMutation({
    mutationFn: () => fetch(`${API_BASE}/api/events/${eventId}/menu`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...newMenuItem, dayNumber: selectedDay }) }).then(r => r.json()),
    onSuccess: () => { invalidate("event-menu"); setNewMenuItem({ mealType: "breakfast", description: "" }); },
  });
  const deleteMenuItem = useMutation({
    mutationFn: (menuId: number) => fetch(`${API_BASE}/api/events/${eventId}/menu/${menuId}`, { method: "DELETE" }),
    onSuccess: () => invalidate("event-menu"),
  });

  if (!eventId || eventLoading) {
    return <div className="flex items-center justify-center h-64 text-muted-foreground">טוען...</div>;
  }

  if (!event || event.error) {
    return <div className="text-center py-16 text-muted-foreground">מפעל לא נמצא</div>;
  }

  const doneTasks = tasks.filter((t: any) => t.done).length;
  const availableScouts = allScouts.filter((s: any) => !participants.some((p: any) => p.scoutId === s.id));
  const numDays = event.endDate && event.date
    ? Math.max(1, Math.ceil((new Date(event.endDate).getTime() - new Date(event.date).getTime()) / 86400000) + 1)
    : 1;

  const tabs: { id: Tab; label: string; icon: React.ElementType; count?: number }[] = [
    { id: "tasks", label: "משימות", icon: ListTodo, count: tasks.length },
    { id: "participants", label: "רשומים", icon: Users, count: participants.length },
    { id: "buses", label: "אוטובוסים", icon: Bus, count: buses.length },
    { id: "menu", label: "תפריט", icon: Utensils, count: menu.length },
    { id: "details", label: "פרטים", icon: Pencil },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-start gap-3 flex-wrap">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/logistics/events")} className="mt-0.5 shrink-0">
          <ArrowRight className="w-5 h-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold truncate">{event.name}</h2>
          <div className="flex items-center flex-wrap gap-3 mt-1 text-sm text-muted-foreground">
            {event.eventType && <span>{EVENT_TYPES[event.eventType] || event.eventType}</span>}
            {event.date && (
              <span className="flex items-center gap-1">
                <CalendarRange className="w-3.5 h-3.5" />
                {new Date(event.date).toLocaleDateString('he-IL')}
                {event.endDate && ` — ${new Date(event.endDate).toLocaleDateString('he-IL')}`}
              </span>
            )}
            {event.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{event.location}</span>}
            {event.responsiblePerson && <span className="flex items-center gap-1"><User className="w-3.5 h-3.5" />{event.responsiblePerson}</span>}
            <Badge variant="outline" className="text-xs">{participants.length} רשומים</Badge>
            <Badge variant="outline" className={`text-xs ${doneTasks === tasks.length && tasks.length > 0 ? "text-green-600 border-green-300" : ""}`}>
              {doneTasks}/{tasks.length} משימות
            </Badge>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1 border-b border-border">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
              {tab.count !== undefined && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${activeTab === tab.id ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="min-h-[400px]">

        {/* TASKS */}
        {activeTab === "tasks" && (
          <div className="space-y-4">
            <div className="flex gap-2 flex-wrap items-end">
              <div className="flex-1 min-w-48">
                <Input
                  placeholder="הוסף משימה חדשה..."
                  value={newTask}
                  onChange={e => setNewTask(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && newTask.trim() && addTask.mutate({ title: newTask.trim(), priority: taskPriority, assignee: taskAssignee || null })}
                />
              </div>
              <Select value={taskPriority} onValueChange={setTaskPriority}>
                <SelectTrigger className="w-28 h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">דחוף</SelectItem>
                  <SelectItem value="normal">רגיל</SelectItem>
                  <SelectItem value="low">נמוך</SelectItem>
                </SelectContent>
              </Select>
              <Input placeholder="אחראי" value={taskAssignee} onChange={e => setTaskAssignee(e.target.value)} className="w-36" />
              <Button size="sm" onClick={() => newTask.trim() && addTask.mutate({ title: newTask.trim(), priority: taskPriority, assignee: taskAssignee || null })} disabled={!newTask.trim()}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {tasks.length > 0 && (
              <div className="bg-muted/30 border rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">התקדמות משימות</span>
                  <span className="font-bold text-sm">{doneTasks}/{tasks.length} בוצעו — {tasks.length > 0 ? Math.round((doneTasks / tasks.length) * 100) : 0}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full transition-all" style={{ width: `${tasks.length > 0 ? (doneTasks / tasks.length) * 100 : 0}%` }} />
                </div>
              </div>
            )}

            <div className="space-y-3">
              {tasks.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <ListTodo className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p>אין משימות עדיין — הוסף משימה למפעל</p>
                </div>
              ) : (
                (() => {
                  const grouped: Record<string, any[]> = {};
                  tasks.forEach((t: any) => {
                    const key = t.assignee || "ללא שיבוץ";
                    if (!grouped[key]) grouped[key] = [];
                    grouped[key].push(t);
                  });
                  return Object.entries(grouped).map(([assignee, groupTasks]) => {
                    const groupDone = groupTasks.filter((t: any) => t.done).length;
                    const groupPct = groupTasks.length > 0 ? Math.round((groupDone / groupTasks.length) * 100) : 0;
                    return (
                      <div key={assignee} className="border rounded-xl overflow-hidden">
                        <div className="bg-muted/30 px-4 py-2.5 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span className="font-semibold text-sm">ממוסרות ל{assignee} ({groupDone}/{groupTasks.length})</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-20 bg-muted rounded-full h-1.5">
                              <div className="bg-primary h-1.5 rounded-full" style={{ width: `${groupPct}%` }} />
                            </div>
                            <span className="text-xs text-muted-foreground">{groupPct}%</span>
                          </div>
                        </div>
                        <div className="divide-y divide-border/50">
                          {groupTasks.map((task: any) => (
                            <TaskRow key={task.id} task={task} onToggle={() => toggleTask.mutate({ taskId: task.id, done: !task.done })} onDelete={() => deleteTask.mutate(task.id)} />
                          ))}
                        </div>
                      </div>
                    );
                  });
                })()
              )}
            </div>
          </div>
        )}

        {/* PARTICIPANTS */}
        {activeTab === "participants" && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <Select value={selectedScout} onValueChange={setSelectedScout}>
                <SelectTrigger className="flex-1"><SelectValue placeholder="בחר חניך להוספה..." /></SelectTrigger>
                <SelectContent>
                  {availableScouts.map((s: any) => (
                    <SelectItem key={s.id} value={String(s.id)}>
                      {s.name} {s.grade ? `(כיתה ${s.grade})` : ""} — {s.gizra}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button onClick={() => selectedScout && addParticipant.mutate(parseInt(selectedScout))} disabled={!selectedScout}>
                <Plus className="w-4 h-4 ml-1" /> הוסף
              </Button>
            </div>

            {participants.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Users className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>אין רשומים למפעל זה — הוסף חניכים מהרשימה</p>
              </div>
            ) : (
              <div className="border rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted/30">
                    <tr>
                      <th className="text-right p-3 font-medium">שם</th>
                      <th className="text-right p-3 font-medium">כיתה</th>
                      <th className="text-right p-3 font-medium">גזרה</th>
                      <th className="text-right p-3 font-medium">אוטובוס</th>
                      <th className="p-3 w-12"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {participants.map((p: any, i: number) => (
                      <tr key={p.id} className={i % 2 === 0 ? "bg-background" : "bg-muted/10"}>
                        <td className="p-3 font-medium">{p.scoutName || `#${p.scoutId}`}</td>
                        <td className="p-3 text-muted-foreground">{p.scoutGrade || "—"}</td>
                        <td className="p-3 text-muted-foreground">{p.scoutGizra || "—"}</td>
                        <td className="p-3">
                          {buses.length > 0 ? (
                            <Select
                              value={p.busId ? String(p.busId) : "none"}
                              onValueChange={async (val) => {
                                await fetch(`${API_BASE}/api/events/${eventId}/participants/${p.id}`, {
                                  method: "DELETE"
                                });
                                await fetch(`${API_BASE}/api/events/${eventId}/participants`, {
                                  method: "POST",
                                  headers: { "Content-Type": "application/json" },
                                  body: JSON.stringify({ scoutId: p.scoutId, busId: val === "none" ? null : parseInt(val) })
                                });
                                invalidate("event-participants");
                              }}
                            >
                              <SelectTrigger className="h-7 text-xs w-32"><SelectValue placeholder="ללא" /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="none">ללא</SelectItem>
                                {buses.map((b: any) => <SelectItem key={b.id} value={String(b.id)}>{b.name}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          ) : "—"}
                        </td>
                        <td className="p-3">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => removeParticipant.mutate(p.id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <p className="text-sm text-muted-foreground">סה״כ: {participants.length} רשומים</p>
          </div>
        )}

        {/* BUSES */}
        {activeTab === "buses" && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl border bg-muted/20 space-y-3">
              <p className="font-semibold text-sm">הוספת אוטובוס</p>
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="שם / מספר אוטובוס *" value={newBus.name} onChange={e => setNewBus(p => ({ ...p, name: e.target.value }))} />
                <Input placeholder="קיבולת" type="number" value={newBus.capacity} onChange={e => setNewBus(p => ({ ...p, capacity: e.target.value }))} />
                <Input placeholder="שם נהג" value={newBus.driverName} onChange={e => setNewBus(p => ({ ...p, driverName: e.target.value }))} />
                <Input placeholder="שעת יציאה" value={newBus.departureTime} onChange={e => setNewBus(p => ({ ...p, departureTime: e.target.value }))} />
                <Input placeholder="נקודת איסוף" className="col-span-2" value={newBus.meetingPoint} onChange={e => setNewBus(p => ({ ...p, meetingPoint: e.target.value }))} />
              </div>
              <Button className="w-full" onClick={() => newBus.name && addBus.mutate()} disabled={!newBus.name || addBus.isPending}>
                <Plus className="w-4 h-4 ml-1" /> הוסף אוטובוס
              </Button>
            </div>

            {buses.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Bus className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>לא הוגדרו אוטובוסים</p>
              </div>
            ) : (
              <div className="grid gap-3 md:grid-cols-2">
                {buses.map((bus: any) => {
                  const assigned = participants.filter((p: any) => p.busId === bus.id).length;
                  return (
                    <div key={bus.id} className="border rounded-xl p-4 bg-card space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-bold text-lg">{bus.name}</p>
                          {bus.capacity && <p className="text-sm text-muted-foreground">{assigned}/{bus.capacity} נוסעים</p>}
                        </div>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => deleteBus.mutate(bus.id)}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                      {bus.capacity && (
                        <div className="w-full bg-muted rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: `${Math.min((assigned / bus.capacity) * 100, 100)}%` }} />
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground space-y-0.5">
                        {bus.driverName && <p>נהג: {bus.driverName}</p>}
                        {bus.departureTime && <p>יציאה: {bus.departureTime}</p>}
                        {bus.meetingPoint && <p>איסוף: {bus.meetingPoint}</p>}
                      </div>
                      {assigned > 0 && (
                        <div className="pt-1">
                          <p className="text-xs font-medium mb-1">נוסעים:</p>
                          <div className="flex flex-wrap gap-1">
                            {participants.filter((p: any) => p.busId === bus.id).map((p: any) => (
                              <span key={p.id} className="text-xs bg-muted px-2 py-0.5 rounded-full">{p.scoutName}</span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* MENU */}
        {activeTab === "menu" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-sm font-medium">יום:</p>
              {Array.from({ length: numDays }, (_, i) => i + 1).map(day => (
                <button
                  key={day}
                  onClick={() => setSelectedDay(day)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${selectedDay === day ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted hover:bg-muted/80"}`}
                >
                  יום {day}
                </button>
              ))}
              {numDays > 1 && selectedDay === numDays ? null : null}
            </div>

            <div className="p-4 rounded-xl border bg-muted/20 space-y-3">
              <div className="flex gap-2">
                <Select value={newMenuItem.mealType} onValueChange={v => setNewMenuItem(p => ({ ...p, mealType: v }))}>
                  <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {MEAL_TYPES.map(m => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Input
                  className="flex-1"
                  placeholder="תיאור הארוחה..."
                  value={newMenuItem.description}
                  onChange={e => setNewMenuItem(p => ({ ...p, description: e.target.value }))}
                  onKeyDown={e => e.key === "Enter" && newMenuItem.description && addMenuItem.mutate()}
                />
                <Button onClick={() => newMenuItem.description && addMenuItem.mutate()} disabled={!newMenuItem.description}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              {MEAL_TYPES.map(({ value, label }) => {
                const dayMenu = menu.filter((m: any) => m.dayNumber === selectedDay && m.mealType === value);
                if (dayMenu.length === 0) return null;
                return (
                  <div key={value} className="border rounded-xl overflow-hidden">
                    <div className="bg-muted/30 px-4 py-2 font-medium text-sm">{label}</div>
                    {dayMenu.map((item: any) => (
                      <div key={item.id} className="flex items-center justify-between px-4 py-2.5 border-t">
                        <p className="text-sm">{item.description}</p>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteMenuItem.mutate(item.id)}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                );
              })}
              {menu.filter((m: any) => m.dayNumber === selectedDay).length === 0 && (
                <div className="text-center py-10 text-muted-foreground">
                  <Utensils className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p>אין תפריט ליום {selectedDay}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* DETAILS */}
        {activeTab === "details" && (
          <div className="space-y-3 max-w-2xl">
            {[
              { label: "שם", value: event.name },
              { label: "סוג", value: EVENT_TYPES[event.eventType] || event.eventType },
              { label: "תאריך התחלה", value: event.date ? new Date(event.date).toLocaleDateString('he-IL') : null },
              { label: "תאריך סיום", value: event.endDate ? new Date(event.endDate).toLocaleDateString('he-IL') : null },
              { label: "מיקום", value: event.location },
              { label: "אחראי", value: event.responsiblePerson },
              { label: "מספר משתתפים צפוי", value: event.participantsCount },
              { label: "תקציב מוקצה", value: event.budgetAllocated ? `₪${parseFloat(event.budgetAllocated).toLocaleString()}` : null },
              { label: "עלות בפועל", value: event.actualCost ? `₪${parseFloat(event.actualCost).toLocaleString()}` : null },
              { label: "הסעות", value: event.transportNeeded },
              { label: "תיאור", value: event.description },
              { label: "הערות", value: event.notes },
            ].filter(f => f.value).map(f => (
              <div key={f.label} className="flex gap-4 py-2 border-b border-border/50 last:border-0">
                <span className="text-muted-foreground w-36 shrink-0 text-sm">{f.label}:</span>
                <span className="font-medium text-sm">{String(f.value)}</span>
              </div>
            ))}
            <Button variant="outline" className="mt-4" onClick={() => setLocation("/logistics/events")}>
              <Pencil className="w-4 h-4 ml-2" /> עריכה מלאה
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

function TaskRow({ task, onToggle, onDelete }: { task: any; onToggle: () => void; onDelete: () => void }) {
  return (
    <div className={`flex items-center gap-3 p-3 rounded-lg border mb-1.5 transition-all ${task.done ? "bg-muted/30 opacity-60" : "bg-card"}`}>
      <Checkbox checked={task.done} onCheckedChange={onToggle} />
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium ${task.done ? "line-through text-muted-foreground" : ""}`}>{task.title}</p>
        {task.assignee && <p className="text-xs text-muted-foreground">אחראי: {task.assignee}</p>}
      </div>
      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive shrink-0" onClick={onDelete}>
        <Trash2 className="w-3.5 h-3.5" />
      </Button>
    </div>
  );
}
