import { useAuth, ROLE_NAMES } from "@/hooks/use-auth";
import { useListPermissions } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import {
  Users,
  CalendarCheck,
  CalendarRange,
  Wallet,
  ShoppingCart,
  ShieldCheck,
  Archive,
  ChevronLeft,
} from "lucide-react";

interface Tile {
  href: string;
  title: string;
  subtitle: string;
  icon: React.ElementType;
  gradient: string;
  iconBg: string;
  show: boolean;
  size?: "large" | "normal";
}

export function Dashboard() {
  const { user, role } = useAuth();
  const [, setLocation] = useLocation();
  const { data: permissions = [] } = useListPermissions({ query: { enabled: !!role } });

  const canAccessHadracha = role === "marcaz_boger" || permissions.some(p => p.role === role && p.section === "hadracha" && p.canAccess);
  const canAccessLogistics = role === "marcaz_boger" || permissions.some(p => p.role === role && p.section === "logistics" && p.canAccess);
  const isAdmin = role === "marcaz_boger";

  const displayName = user?.name || (role ? ROLE_NAMES[role] : "");

  const tiles: Tile[] = [
    {
      href: "/hadracha/scouts",
      title: "רשימות חניכים",
      subtitle: "חניכות, חניכים, מדריכים — ניהול מלא",
      icon: Users,
      gradient: "from-blue-600 to-blue-700",
      iconBg: "bg-blue-500/30",
      show: canAccessHadracha,
      size: "large",
    },
    {
      href: "/hadracha/attendance",
      title: "נוכחות",
      subtitle: "סימון ומעקב נוכחות",
      icon: CalendarCheck,
      gradient: "from-sky-500 to-sky-600",
      iconBg: "bg-sky-400/30",
      show: canAccessHadracha,
    },
    {
      href: "/logistics/events",
      title: "מפעלים",
      subtitle: "תכנון, ניהול ומעקב מפעלים",
      icon: CalendarRange,
      gradient: "from-red-600 to-red-700",
      iconBg: "bg-red-500/30",
      show: canAccessLogistics,
      size: "large",
    },
    {
      href: "/logistics/budget",
      title: "תקציב",
      subtitle: "תקציב שנתי, הכנסות והוצאות",
      icon: Wallet,
      gradient: "from-rose-500 to-rose-600",
      iconBg: "bg-rose-400/30",
      show: canAccessLogistics,
    },
    {
      href: "/logistics/procurement",
      title: "הזמנות רכש",
      subtitle: "רכישות וספקים",
      icon: ShoppingCart,
      gradient: "from-indigo-600 to-indigo-700",
      iconBg: "bg-indigo-500/30",
      show: canAccessLogistics,
    },
    {
      href: "/years",
      title: "ארכיון שנים",
      subtitle: "שמירת ידע + סגירת שנה",
      icon: Archive,
      gradient: "from-slate-600 to-slate-700",
      iconBg: "bg-slate-500/30",
      show: isAdmin,
    },
    {
      href: "/admin",
      title: "ניהול",
      subtitle: "משתמשים והרשאות",
      icon: ShieldCheck,
      gradient: "from-amber-600 to-amber-700",
      iconBg: "bg-amber-500/30",
      show: isAdmin,
    },
  ];

  const visible = tiles.filter(t => t.show);
  const largeTiles = visible.filter(t => t.size === "large");
  const normalTiles = visible.filter(t => t.size !== "large");

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col justify-center py-6 animate-in fade-in duration-300">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="w-2 h-8 rounded-full bg-blue-600" />
          <h1 className="text-3xl font-bold">מנהל השבט</h1>
          <div className="w-2 h-8 rounded-full bg-red-600" />
        </div>
        <p className="text-muted-foreground">
          שלום <span className="font-semibold text-foreground">{displayName}</span> — לאיזה מסך תרצה להיכנס?
        </p>
      </div>

      <div className="space-y-4 max-w-4xl mx-auto w-full">
        {largeTiles.length > 0 && (
          <div className={`grid gap-4 ${largeTiles.length === 2 ? "grid-cols-2" : "grid-cols-1"}`}>
            {largeTiles.map(tile => (
              <TileButton key={tile.href} tile={tile} onClick={() => setLocation(tile.href)} large />
            ))}
          </div>
        )}

        {normalTiles.length > 0 && (
          <div className={`grid gap-4 ${
            normalTiles.length === 1 ? "grid-cols-1" :
            normalTiles.length === 2 ? "grid-cols-2" :
            normalTiles.length === 3 ? "grid-cols-3" :
            "grid-cols-2 md:grid-cols-4"
          }`}>
            {normalTiles.map(tile => (
              <TileButton key={tile.href} tile={tile} onClick={() => setLocation(tile.href)} />
            ))}
          </div>
        )}
      </div>

      {visible.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <ShieldCheck className="w-12 h-12 mx-auto mb-4 opacity-30" />
          <p>אין גישה. פנה למרכז בוגר להגדרת הרשאות.</p>
        </div>
      )}
    </div>
  );
}

function TileButton({ tile, onClick, large }: { tile: Tile; onClick: () => void; large?: boolean }) {
  const Icon = tile.icon;
  return (
    <button
      onClick={onClick}
      className={`
        group relative overflow-hidden text-right rounded-3xl
        bg-gradient-to-br ${tile.gradient}
        text-white shadow-lg
        transition-all duration-200 hover:shadow-2xl hover:-translate-y-1 active:translate-y-0
        focus:outline-none focus:ring-4 focus:ring-white/30
        ${large ? "p-8 min-h-[140px]" : "p-6 min-h-[110px]"}
        w-full
      `}
    >
      <div className="relative z-10 flex flex-col h-full justify-between">
        <div className={`${tile.iconBg} rounded-2xl p-3 w-fit mb-3`}>
          <Icon className={large ? "w-8 h-8" : "w-6 h-6"} />
        </div>
        <div>
          <h3 className={`font-bold leading-tight ${large ? "text-2xl" : "text-lg"}`}>{tile.title}</h3>
          <p className={`text-white/75 mt-1 ${large ? "text-sm" : "text-xs"}`}>{tile.subtitle}</p>
        </div>
      </div>
      <div className="absolute bottom-4 left-4 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <ChevronLeft className="w-5 h-5 text-white/80" />
      </div>
      <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-white/5 group-hover:bg-white/10 transition-colors" />
      <div className="absolute -top-4 -right-4 w-20 h-20 rounded-full bg-white/5" />
    </button>
  );
}
