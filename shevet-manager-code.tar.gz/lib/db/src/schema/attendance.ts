import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { scoutsTable } from "./scouts";
import { eventsTable } from "./events";

export const attendanceTable = pgTable("attendance", {
  id: serial("id").primaryKey(),
  scoutId: integer("scout_id").notNull().references(() => scoutsTable.id, { onDelete: "cascade" }),
  eventId: integer("event_id").references(() => eventsTable.id, { onDelete: "cascade" }),
  date: timestamp("date", { withTimezone: true }),
  status: text("status").notNull().default("present"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAttendanceSchema = createInsertSchema(attendanceTable).omit({ id: true, createdAt: true });
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendanceTable.$inferSelect;
